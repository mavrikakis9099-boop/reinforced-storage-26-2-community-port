"""Execute the production Java screen and test its draw map, not source markers.

The Java recording adapters do not emulate Minecraft: this proves composition and
UV geometry, not Fabric linkage, GPU behavior, external mod hooks, or in-game acceptance.
Only the standard library and a JDK with the jdk.compiler module are required.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOT = ROOT / "reinfcore/src/main/java"
TIERS = {"copper": 45, "iron": 54, "gold": 81, "diamond": 108, "netherite": 108}
CASES = [(f"{tier}_{kind}", size, double)
         for tier, size in TIERS.items()
         for kind, double in (("barrel", False), ("chest", False), ("double_chest", True))]


def compile_probe(output_dir, screen_override=None):
    java = shutil.which("java")
    if java is None:
        raise RuntimeError("GUI composition tests require a JDK (Java 17+; the mod build requires 25).")
    sources = list((ROOT / "tests/gui_harness/java").rglob("*.java"))
    screen = JAVA_ROOT / "atonkish/reinfcore/client/gui/screen/ReinforcedStorageScreen.java"
    sources += [Path(screen_override) if screen_override else screen]
    sources += [JAVA_ROOT / ("atonkish/reinfcore/" + path) for path in (
        "util/ReinforcedStorageScreenModel.java", "util/ReinforcedStorageScreenType.java",
        "util/ReinforcingMaterial.java", "util/math/Point2i.java")]
    subprocess.run([java, "com.sun.tools.javac.Main", "--release", "17", "-d", str(output_dir),
                    *map(str, sources)], check=True, capture_output=True, text=True)
    return java


def run_probe(java, output_dir, size, double):
    result = subprocess.run([java, "-cp", str(output_dir),
                             "atonkish.reinfcore.client.gui.screen.GuiRenderProbe",
                             str(size), str(double).lower()], check=True, capture_output=True, text=True)
    parsed = {"SIZE": [], "BLIT": [], "TEXT": [], "WIDGET": []}
    for line in result.stdout.splitlines():
        kind, *values = line.split()
        parsed[kind].append(tuple(map(int, values)))
    return parsed


def draw_map(operations):
    mapping, coverage = {}, Counter()
    for x, y, u, v, width, height, rw, rh, tw, th in operations:
        if width <= 0 or height <= 0 or (rw, rh, tw, th) != (width, height, 256, 256):
            raise AssertionError("Draw must copy an unscaled, positive region using 256-unit UVs")
        if not (0 <= u and 0 <= v and u + rw <= 176 and v + rh <= 222):
            raise AssertionError("Draw reads outside the used generic_54 artwork")
        for dy in range(height):
            for dx in range(width):
                point = (x + dx, y + dy)
                mapping[point] = (u + dx, v + dy)
                coverage[point] += 1
    return mapping, coverage


def geometry(size, double):
    count = size * (2 if double else 1)
    columns = 9 if count <= 81 else count // 9
    rows = count // columns
    # Probe's screen origin is (20,30); legacy item coordinates are (7,17).
    return count, columns, rows, 19, 29, (columns - 9) * 9


def fixture_pixel(u, v, style, scale=1, sub_x=0, sub_y=0):
    """Independent, deterministic texture styles with the conventional atlas layout."""
    dark = style != "light"
    background = (70, 72, 73) if dark else (198, 198, 198)
    top = (25, 26, 27) if dark else (55, 55, 55)
    bottom = (110, 111, 112) if dark else (255, 255, 255)
    rgb = background
    cells = [(7, 17, 9, 6), (7, 139, 9, 3), (7, 197, 9, 1)]
    for gx, gy, cols, rows in cells:
        if gx <= u < gx + cols * 18 and gy <= v < gy + rows * 18:
            dx, dy = (u - gx) % 18, (v - gy) % 18
            rgb = top if dx == 0 or dy == 0 else bottom if dx == 17 or dy == 17 else (
                (51, 52, 53) if dark else (139, 139, 139))
            break
    if style == "patterned":
        rgb = tuple((value + (u * 3 + v * 7) % 19) % 256 for value in rgb)
    if scale > 1:
        rgb = tuple((value + sub_x + sub_y * scale) % 256 for value in rgb)
    alpha = 144 if style == "translucent" else 255
    # Transparent corners exercise non-rectangular artwork without an opaque underlay.
    if style == "translucent" and (u < 2 or u > 173) and (v < 2 or v > 219):
        alpha = 0
    return (*rgb, alpha)


class GuiCompositionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="reinforced-gui-java-")
        cls.addClassCleanup(cls.temp.cleanup)
        cls.java = compile_probe(cls.temp.name)

    @classmethod
    @lru_cache(maxsize=None)
    def probe(cls, size, double):
        return run_probe(cls.java, cls.temp.name, size, double)

    def test_complete_cell_art_for_every_slot_in_all_15_variants(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, cols, rows, px, py, offset = geometry(size, double)
                mapping, coverage = draw_map(self.probe(size, double)["BLIT"])
                for row in range(rows):
                    for col in range(cols):
                        for dy in range(18):
                            for dx in range(18):
                                point = (px + 7 + col * 18 + dx, py + 17 + row * 18 + dy)
                                expected = (7 + col % 9 * 18 + dx, 17 + row % 6 * 18 + dy)
                                self.assertEqual(mapping.get(point), expected, (name, row, col, dx, dy))
                                self.assertEqual(coverage[point], 1)

    def test_player_panel_is_intact_centered_and_drawn_once(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, _, rows, px, _, offset = geometry(size, double)
                mapping, coverage = draw_map(self.probe(size, double)["BLIT"])
                player_y = 30 + 17 + rows * 18
                for dy in range(96):
                    for dx in range(176):
                        point = (px + offset + dx, player_y + dy)
                        self.assertEqual(mapping.get(point), (dx, 126 + dy))
                        self.assertEqual(coverage[point], 1)

    def test_player_shoulders_are_not_painted(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, cols, rows, px, py, offset = geometry(size, double)
                mapping, _ = draw_map(self.probe(size, double)["BLIT"])
                footer_end = py + 17 + rows * 18 + 3
                for y in range(footer_end, 30 + 114 + rows * 18):
                    for x in range(px, px + offset):
                        self.assertNotIn((x, y), mapping)
                    for x in range(px + offset + 176, px + 14 + cols * 18):
                        self.assertNotIn((x, y), mapping)

    def test_all_draws_are_disjoint_and_use_valid_unscaled_texture_regions(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, coverage = draw_map(self.probe(size, double)["BLIT"])
                self.assertTrue(coverage)
                self.assertEqual(max(coverage.values()), 1, "Overdraw breaks translucent packs")

    def test_side_frames_reach_the_bottom_and_move_to_the_new_right_edge(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, cols, rows, px, py, _ = geometry(size, double)
                mapping, _ = draw_map(self.probe(size, double)["BLIT"])
                for y in range(rows * 18):
                    for x in range(7):
                        self.assertEqual(mapping[(px + x, py + 17 + y)], (x, 17 + y % 108))
                        self.assertEqual(mapping[(px + 7 + cols * 18 + x, py + 17 + y)],
                                         (169 + x, 17 + y % 108))

    def test_label_positions_and_accepted_white_color_are_preserved(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, cols, rows, _, _, offset = geometry(size, double)
                probe = self.probe(size, double)
                self.assertEqual(probe["SIZE"], [(14 + cols * 18, rows * 18 + 114)])
                self.assertEqual(probe["TEXT"], [(8, 6, -1), (7 + offset, 20 + rows * 18, -1)])

    def test_nemo_player_buttons_follow_the_centered_player_panel(self):
        for name, size, double in CASES:
            with self.subTest(name=name):
                _, cols, rows, _, _, offset = geometry(size, double)
                image_width = 14 + cols * 18
                expected_y = 30 + 20 + rows * 18 - 2
                expected_x = [20 + image_width + right - offset
                              for right in (-61, -47, -33, -19)]
                expected_x.append(20 + image_width - 5)
                self.assertEqual(self.probe(size, double)["WIDGET"],
                                 [(x, expected_y) for x in expected_x])

    def test_light_dark_patterned_translucent_and_high_resolution_cell_pixels(self):
        mapping, coverage = draw_map(self.probe(108, True)["BLIT"])
        for style in ("light", "dark", "patterned", "translucent"):
            for scale in (1, 2, 4):
                with self.subTest(style=style, scale=scale):
                    for row, col in ((0, 0), (0, 9), (6, 0), (6, 9), (8, 23)):
                        for dy in range(18):
                            for dx in range(18):
                                point = (26 + col * 18 + dx, 46 + row * 18 + dy)
                                source = mapping[point]
                                expected = (7 + col % 9 * 18 + dx, 17 + row % 6 * 18 + dy)
                                for sub_x, sub_y in ((0, 0), (scale - 1, scale - 1)):
                                    self.assertEqual(fixture_pixel(*source, style, scale, sub_x, sub_y),
                                                     fixture_pixel(*expected, style, scale, sub_x, sub_y))
                                self.assertEqual(coverage[point], 1)

    def test_no_pixel_expansion_can_pass_the_draw_map(self):
        with self.assertRaises(AssertionError):
            draw_map([(20, 30, 4, 4, 446, 276, 1, 1, 256, 256)])


if __name__ == "__main__":
    unittest.main()
