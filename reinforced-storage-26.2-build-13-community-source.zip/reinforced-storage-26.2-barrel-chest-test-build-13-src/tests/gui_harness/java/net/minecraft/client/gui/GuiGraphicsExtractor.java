package net.minecraft.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Recording adapter, NOT a Minecraft renderer or API compatibility proof. */
public final class GuiGraphicsExtractor {
    public final List<int[]> blits = new ArrayList<>();
    public final List<int[]> labels = new ArrayList<>();

    public void blit(Object pipeline, Identifier texture, int x, int y, float u, float v,
            int width, int height, int regionWidth, int regionHeight, int textureWidth, int textureHeight) {
        if (!texture.value().equals("minecraft:textures/gui/container/generic_54.png")) {
            throw new AssertionError("Unexpected texture " + texture);
        }
        blits.add(new int[] {x, y, (int) u, (int) v, width, height,
                regionWidth, regionHeight, textureWidth, textureHeight});
    }

    public void text(Object font, Component text, int x, int y, int color, boolean shadow) {
        labels.add(new int[] {x, y, color});
    }
}
