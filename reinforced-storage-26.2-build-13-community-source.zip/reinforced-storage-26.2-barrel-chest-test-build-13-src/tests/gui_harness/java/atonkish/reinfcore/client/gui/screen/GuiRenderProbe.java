package atonkish.reinfcore.client.gui.screen;

import atonkish.reinfcore.screen.ReinforcedStorageMenu;
import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** Executes the actual production screen. All output coordinates are GUI logical pixels. */
public final class GuiRenderProbe {
    public static void main(String[] args) {
        ReinforcingMaterial material = new ReinforcingMaterial("test", Integer.parseInt(args[0]), null);
        ReinforcedStorageMenu menu = new ReinforcedStorageMenu(material, Boolean.parseBoolean(args[1]));
        ReinforcedStorageScreen screen = new ReinforcedStorageScreen(menu, new Inventory(), Component.literal("Test"));
        screen.init();
        GuiGraphicsExtractor graphics = new GuiGraphicsExtractor();
        screen.extractBackground(graphics, 0, 0, 0);
        screen.extractLabels(graphics, 0, 0);
        System.out.println("SIZE " + screen.getImageWidth() + " " + screen.getImageHeight());
        for (int[] op : graphics.blits) { emit("BLIT", op); }
        for (int[] label : graphics.labels) { emit("TEXT", label); }
        screen.children().forEach(child -> {
            if (child instanceof net.minecraft.client.gui.components.AbstractWidget widget) {
                System.out.println("WIDGET " + widget.getX() + " " + widget.getY());
            }
        });
    }
    private static void emit(String kind, int[] values) {
        StringBuilder result = new StringBuilder(kind);
        for (int value : values) { result.append(' ').append(value); }
        System.out.println(result);
    }
}
