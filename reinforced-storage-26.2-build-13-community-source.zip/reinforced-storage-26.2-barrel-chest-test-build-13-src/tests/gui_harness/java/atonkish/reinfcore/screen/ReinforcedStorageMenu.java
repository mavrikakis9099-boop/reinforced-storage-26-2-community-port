package atonkish.reinfcore.screen;
import atonkish.reinfcore.util.ReinforcingMaterial;
public final class ReinforcedStorageMenu {
    private final ReinforcingMaterial material;
    private final boolean doubleBlock;
    public ReinforcedStorageMenu(ReinforcingMaterial material, boolean doubleBlock) {
        this.material = material;
        this.doubleBlock = doubleBlock;
    }
    public ReinforcingMaterial getMaterial() { return material; }
    public boolean isDoubleBlock() { return doubleBlock; }
    public Container getContainer() { return new Container(material.getSize() * (doubleBlock ? 2 : 1)); }
    public record Container(int size) { public int getContainerSize() { return size; } }
}
