package atonkish.reinfcore;

import atonkish.reinfcore.util.ReinforcedStorageScreenType;

/**
 * Minimal compatibility configuration for the first 26.2 migration build.
 *
 * <p>The 1.21.11 release used Cloth AutoConfig. Configuration UI integration is intentionally
 * deferred until storage identity and persistence have passed migration tests.</p>
 */
public final class ReinforcedCoreConfig {
    public ReinforcedStorageScreenType screenType = ReinforcedStorageScreenType.SINGLE;
    public ScrollScreen scrollScreen = new ScrollScreen();

    public static final class ScrollScreen {
        public int rows = 6;
    }
}
