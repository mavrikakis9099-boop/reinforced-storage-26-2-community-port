package atonkish.reinfcore;

import atonkish.reinfcore.item.ModCreativeModeTabs;

import net.fabricmc.api.ModInitializer;

/** Shared compatibility layer for the Reinforced Storage 26.2 port. */
public final class ReinforcedCoreMod implements ModInitializer {
    public static final String MOD_ID = "reinfcore";
    public static final ReinforcedCoreConfig CONFIG = new ReinforcedCoreConfig();

    @Override
    public void onInitialize() {
        ModCreativeModeTabs.init();
    }
}
