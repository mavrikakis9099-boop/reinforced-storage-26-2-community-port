package atonkish.reinfcore.screen;

import atonkish.reinfcore.util.ReinforcedStorageScreenModel;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfcore.util.math.Point2i;

import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Arbitrary-size reinforced storage menu.
 *
 * <p>The layout math deliberately mirrors Reinforced Core 4.0.9 for both single and double
 * storage. SCROLL rendering/scroll-slot behavior is deferred until the world-data migration path
 * is proven.</p>
 */
public final class ReinforcedStorageMenu extends AbstractContainerMenu implements ReinforcedStorageScreenHandler {
    private static final int SLOT_SIZE = 18;
    private static final int PLAYER_HOTBAR_SIZE = 9;
    private static final int PLAYER_INVENTORY_ROWS = 3;
    private static final int PLAYER_INVENTORY_COLUMNS = 9;

    private final ReinforcingMaterial material;
    private final Container container;
    private final boolean doubleBlock;

    /** Client constructor used by the registered MenuType. */
    public ReinforcedStorageMenu(MenuType<?> menuType, ReinforcingMaterial material, boolean doubleBlock, int containerId, Inventory inventory) {
        this(menuType, material, doubleBlock, containerId, inventory,
                new SimpleContainer(ReinforcedStorageScreenModel.getContainerInventorySize(material, doubleBlock)));
    }

    /** Server constructor used by reinforced block entities. */
    public ReinforcedStorageMenu(
            MenuType<?> menuType,
            ReinforcingMaterial material,
            boolean doubleBlock,
            int containerId,
            Inventory playerInventory,
            Container container
    ) {
        super(menuType, containerId);
        this.material = material;
        this.container = container;
        this.doubleBlock = doubleBlock;

        int expectedSize = ReinforcedStorageScreenModel.getContainerInventorySize(material, doubleBlock);
        if (container.getContainerSize() != expectedSize) {
            throw new IllegalArgumentException(
                    "Container size " + container.getContainerSize() + " does not match reinforced tier "
                            + material.getName() + " (" + expectedSize + ")"
            );
        }

        container.startOpen(playerInventory.player);

        ReinforcedStorageScreenModel model = new ReinforcedStorageScreenModel(material, doubleBlock);
        Point2i containerPoint = model.getContainerInventoryPoint();
        Point2i playerPoint = model.getPlayerInventoryPoint();
        int containerSize = expectedSize;
        int columns = ReinforcedStorageScreenModel.getContainerInventoryColumns(containerSize);
        int rows = containerSize / columns;

        // The first migration build intentionally implements the non-scrolling physical slot layout.
        for (int row = 0; row < rows; row++) {
            for (int column = 0; column < columns; column++) {
                int index = column + row * columns;
                addSlot(new Slot(container, index,
                        containerPoint.getX() + column * SLOT_SIZE,
                        containerPoint.getY() + row * SLOT_SIZE));
            }
        }

        // Player main inventory.
        for (int row = 0; row < PLAYER_INVENTORY_ROWS; row++) {
            for (int column = 0; column < PLAYER_INVENTORY_COLUMNS; column++) {
                addSlot(new Slot(playerInventory, column + row * PLAYER_INVENTORY_COLUMNS + PLAYER_HOTBAR_SIZE,
                        playerPoint.getX() + column * SLOT_SIZE,
                        playerPoint.getY() + row * SLOT_SIZE));
            }
        }

        // Hotbar.
        int hotbarY = playerPoint.getY() + 58;
        for (int column = 0; column < PLAYER_HOTBAR_SIZE; column++) {
            addSlot(new Slot(playerInventory, column,
                    playerPoint.getX() + column * SLOT_SIZE,
                    hotbarY));
        }
    }

    public ReinforcingMaterial getMaterial() {
        return material;
    }

    /** Underlying world container; required by the vanilla-style opener counters. */
    public Container getContainer() {
        return container;
    }

    public boolean isDoubleBlock() {
        return doubleBlock;
    }

    @Override
    public boolean stillValid(Player player) {
        return container.stillValid(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (slot == null || !slot.hasItem()) {
            return result;
        }

        ItemStack source = slot.getItem();
        result = source.copy();
        int containerSlots = container.getContainerSize();
        int inventoryEnd = containerSlots + Inventory.INVENTORY_SIZE;

        if (slotIndex < containerSlots) {
            if (!moveItemStackTo(source, containerSlots, inventoryEnd, true)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(source, 0, containerSlots, false)) {
            return ItemStack.EMPTY;
        }

        if (source.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }

        return result;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        container.stopOpen(player);
    }
}
