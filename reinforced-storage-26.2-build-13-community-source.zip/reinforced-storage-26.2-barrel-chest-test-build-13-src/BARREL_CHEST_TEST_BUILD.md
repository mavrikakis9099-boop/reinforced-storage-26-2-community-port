# Reinforced Barrels + Chests — 26.2 Test Build 13

## Renderer and sorting compatibility 13

Build 13 preserves the accepted Build 6 migration behavior, the Build 8 placed-chest renderer and
the Build 9 Nemo marker. It adds the adaptive renderer and Nemo alignment correction described below while keeping all
world-data and menu semantics unchanged:

- `ReinforcedStorageMenu` implements the historical
  `atonkish.reinfcore.screen.ReinforcedStorageScreenHandler` marker type. Nemo's Inventory Sorting
  26.2-1.21.3 recognizes that exact binary name, so its normal sorting controls can be injected
  into reinforced barrel/chest screens without a dependency on Nemo, a mixin into Nemo, or any
  change to menu IDs, slot ordering, click handling or saved inventories.
- The inventory screen copies complete cells and repeats frame strips from the active vanilla
  chest sheet. Unlike Build 11, it explicitly paints every storage-slot background. It neither
  overdraws another slot sprite nor enlarges one pixel into a blank panel. The player panel is
  centered, its unused side spaces are unpainted, and labels remain white. Legacy menu coordinates
  are unchanged; cell bevels are aligned one pixel outside the actual item rectangles.
- Nemo's automatic lower inventory buttons are shifted left by the storage expansion amount so
  they remain aligned with the centered player panel. Upper container buttons still follow the
  container's right edge, and explicit Nemo x/y configuration remains unchanged.

The optional `compat_resource_pack/` directory is a separate client resource pack. Its atlas aliases
map the five reinforced chest tiers to vanilla `normal`, `normal_left` and `normal_right` sprites;
its barrel model overrides map all five tiers to vanilla barrel textures. Enable it when the user's
dark/global pack should control reinforced storage visuals. Disable it to return to the tier-colored
reinforced skins. The bridge contains no PNGs and changes no world or item data.

### Build 13 acceptance gate

1. Compile with `tools/build_barrel_chest.sh`, then inspect both `port.13` jars before installation.
   The script includes executable Java GUI-composition tests as well as the static migration gate.
2. Install the two matching jars in the disposable 26.2 instance with Fabric API and Nemo's
   Inventory Sorting 26.2-1.21.3. Keep Build 6/Run 2 and an untouched copy of the accepted fixture.
   Do not use the real world for the first run.
3. With resource packs disabled, open every reinforced barrel, single chest and double chest. Verify
   Nemo's sort buttons appear, sort storage and player inventory in both directions, and do not alter
   item counts, slot capacities, names, components, hoppers or opening statistics.
4. With `Better-GUI-1.9.1.zip` disabled, open all five barrel tiers and all five chest tiers,
   including both halves of double chests. Confirm there is one slot border per slot, all slots are
   aligned, and both labels are white.
5. Enable `Better-GUI-1.9.1.zip`, press F3+T, and repeat the same checks. Confirm the custom screens
   inherit the pack theme without doubled borders, missing added-slot backgrounds, a left-shifted
   player panel, or lower Nemo buttons detached from that panel. Check the right edge and last row,
   and confirm the world is visible beside the player panel. Repeat for all single and double
   inventories, using items in the final slots.
6. Enable the optional `compat_resource_pack` above the reinforced retexture packs. Keep the dark
   global pack above the bridge. Press F3+T and verify both single and double placed chests and all
   barrel tiers use the dark pack's vanilla chest/barrel surfaces, including open states.
7. Disable the bridge, reload resources, and verify the original tier-colored resource packs still
   work. This is an intentional reversible choice, not a world-data change.
8. Save, restart and reopen the disposable world. Check final slots and opening counters again. If
   anything fails, provide `latest.log` and a screenshot; source or compiler success alone is not a
   runtime acceptance pass.

## Renderer correction 8

Build 7 failed compilation: `ChestRenderState.customSprite` is a NeoForge-added field, not part of
vanilla Minecraft or Fabric. The earlier statement that vanilla provides this hook was incorrect.
The static text checks could not detect that API mismatch and were not proof of Java compatibility.

Build 8 removes that field dependency entirely. Each registered reinforced tier gets a renderer
with immutable single/left/right sprite identifiers. State extraction is inherited unchanged from
vanilla `ChestRenderer`; the submission method uses the genuine 26.2 chest models, facing transform,
cubic lid easing, combined lighting, overlay values, atlas lookup and breaking overlay. Christmas
render states delegate to vanilla submission. There are no new mixins or reflection hooks.

The API was checked against Mojang's actual 26.2 client jar (SHA-1
`2dc72797acbc1b63fc16a11c4ac393605f453754`), not a loader-patched Javadoc mirror. The two renderer
implementation classes compile with Java 25 against that jar and the uploaded, accepted Build 6
mod classes. Full Fabric/Gradle compilation and in-game visual verification remain separate gates.

The original `reinfchest:entity/chest/<tier>/<variant>` paths and all 15 original PNGs remain in
use. Build 8's renderer and the supplied reinforced chest/barrel packs were runtime-tested by the
owner before Build 9. No item models or inventory rendering code changed in Build 8.

`docs/build6_runtime_sha256.json` freezes 171 migration-proven runtime files outside the explicitly
scoped client visual changes. The preflight now rejects changes to these files, NeoForge sprite hooks,
incorrect atlas prefixes, altered tier textures, and unexpected runtime files. It explicitly does
not claim that static checks replace compilation or runtime testing.

Build 8's visual acceptance was completed by the user before Build 9: placed chest textures, lids,
orientations and the supplied reinforced chest/barrel packs worked as expected. Build 9 keeps that
renderer and adds the opt-in vanilla-texture bridge described above.

## Migration iteration 6

The controlled 1.21.11 → 26.2 Run 1 proved exact preservation of all 20 reinforced block
entities, all 109 populated slots, all stack counts, item components, custom names, final-slot
contents, nested reinforced items, vanilla-chest references, and Ender Chest references.

Run 1 also exposed a non-storage compatibility omission in the server log: the five legacy
`minecraft:open_<tier>_barrel` and five `minecraft:open_<tier>_chest` custom-stat registry keys
were not registered by Test Build 5. Minecraft therefore discarded those ten historical counters
when it rewrote the player's statistics file. No block or inventory data was affected.

Test Build 6 restores the original registry-key/value arrangement and per-tier increment behavior.
The deliberately un-namespaced registry-key overload is required for compatibility with the
1.21.11 statistics JSON; the statistic values remain in the `reinfbarrel` and `reinfchest`
namespaces. Run 2 must start from a fresh copy of the 1.21.11 V2 master because Run 1's rewritten
statistics file has already omitted those counters.

## Functional iteration 5

Fresh-world testing of Test Build 4 passed barrel/chest placement, capacities, item transfers,
save/reload, complete client restart, survival recipes, hopper transfer, barrel textures, and chest
mechanics. It also identified one concrete omission: the ten storage items were registered but were
not exposed in the Creative inventory.

Test Build 5 restores the exact legacy discovery behavior. Every reinforced barrel and chest is
added to the vanilla Functional Blocks tab, the vanilla Redstone Blocks tab, and the dedicated
`reinfcore:reinforced_storage` tab titled “Reinforced Storage.” This uses Fabric 26.2's renamed
creative-tab output API. No block, item, block-entity, menu, inventory, or serialization identity
changed.

## Runtime iteration 4

Test Build 3 compiled and reached the Minecraft 26.2 title screen with both storage mods,
their byte-identical embedded `reinfcore`, and all five barrel/chest tiers loaded. The only logged
runtime error was the launcher's unrelated optional Linux narrator library (`libflite.so`).

Test Build 4 adds a standard client entrypoint and registers Minecraft 26.2's vanilla
`ChestRenderer` for all five legacy reinforced-chest block-entity types. This is deliberately a
diagnostic renderer: placed reinforced chests should be visible and animate correctly, but may use
the vanilla chest surface during migration testing. Tier-specific texture parity is deferred until
inventory integrity has passed. No registry, inventory, menu, block-entity, or serialization code
changed in this iteration.

## Compiler iteration 3

Test Build 3 fixes the next Minecraft 26.2 compiler failure reported by Test Build 2.
Vanilla block-entity constants moved from `BlockEntityType` into the new `BlockEntityTypes`
catalogue, so the migration-critical barrel valid-block bridge now targets
`BlockEntityTypes.BARREL`. The accessor behavior and mutable valid-block set remain unchanged.

## Compiler iteration 2

Test Build 2 fixes the first Minecraft 26.2 compiler failure reported by Test Build 1.
`AbstractContainerScreen.imageWidth` and `imageHeight` are final in 26.2, so the diagnostic
storage screen now calculates its legacy-compatible dimensions before construction and supplies
them through the five-argument superclass constructor. A static regression check prevents later
code from assigning either final field after construction.

## Scope

This branch intentionally excludes Reinforced Shulker Boxes. The first executable milestone is only:

- `reinfcore` 4.0.9 compatibility layer
- `reinfbarrel` 2.7.5 world-identity port
- `reinfchest` 4.0.0-beta world-identity port

Migration correctness remains the constraint. Build 13 changes only the client screen/compatibility
surface after Build 6 passed the controlled migration test; the menu change is accepted only through
the narrow normalization rule in `tools/verify_legacy_contract.py`.

## Build prerequisites

- Minecraft target: 26.2
- Java: 25
- Fabric Loader target: 0.19.5
- Fabric Loom: 1.17.20
- Fabric API: 0.160.0+26.2
- Gradle: current stable (9.7.1 is current in Arch Extra; use the distro package for the first compile)

Run:

```bash
./tools/build_barrel_chest.sh
```

Successful output is copied to `dist/`.

## Test instance requirements

Use a new Minecraft 26.2 Fabric instance and a **copy** of the 1.21.11 test world. Do not open the only copy of a valuable world.

For Test Build 5, install only the minimum needed mods:

1. Fabric API for 26.2
2. the generated Reinforced Barrels jar
3. the generated Reinforced Chests jar

`reinfcore` is embedded in each storage jar; do not separately add the old 1.21.11 core jar.

Do not add Iris/Sodium/shaders or the rest of the modpack yet. First prove storage integrity in isolation.

## 1.21.11 source-world fixture

Before copying the test world forward, populate representative existing containers in 1.21.11:

- one Copper, Iron, Gold, Diamond and Netherite reinforced barrel
- one single Copper, Iron, Gold, Diamond and Netherite reinforced chest
- at least one double reinforced chest at each tier if practical
- put items in slot 0, middle slots, and the final slot of every container
- include full stacks (64), partial stacks (e.g. 37), non-stackables, damaged tools, named/enchanted items and component-bearing items such as potions/maps
- give at least one chest/barrel a custom name

Record the expected counts before upgrade. Screenshots are useful, but the item counts are the acceptance truth.

## First 26.2 acceptance checks

A pass requires all of the following:

- all ten storage items appear in Functional Blocks, Redstone Blocks, and the dedicated
  Reinforced Storage creative tab
- world loads without missing-block/missing-block-entity failures for `reinfbarrel:*` and `reinfchest:*`
- every reinforced barrel/chest is still present at the same position and tier
- every test slot contains the same item, count and item components
- especially verify no stack was reduced to count `1`
- highest-numbered slots survive (45/54/81/108 single capacities and 90/108/162/216 double capacities)
- single and double chests open
- barrel open/close state changes correctly
- chest lids/viewer counts behave correctly
- shift-click does not delete or duplicate items
- hoppers/comparators are deferred until basic inventory integrity passes

The storage screen remains compatibility-first. Build 13's sorting and resource-pack checks are
independent of Build 6's passed migration fixture; they must still be runtime-tested in a disposable
world before the mod is called ready for the full instance.
