#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

LOG="$ROOT/build-barrel-chest.log"
exec > >(tee "$LOG") 2>&1

echo "Reinforced Storage 26.2 — Barrel/Chest Test Build 13"
echo "Log: $LOG"
echo

java_major() {
  java -version 2>&1 | sed -n '1s/.*version "\([0-9][0-9]*\).*/\1/p'
}

JAVA_MAJOR="$(java_major || true)"
if [[ "$JAVA_MAJOR" != "25" && -x /usr/lib/jvm/java-25-openjdk/bin/java ]]; then
  export JAVA_HOME=/usr/lib/jvm/java-25-openjdk
  export PATH="$JAVA_HOME/bin:$PATH"
  JAVA_MAJOR="$(java_major || true)"
fi

if [[ "$JAVA_MAJOR" != "25" ]]; then
  echo "ERROR: Java 25 is required for Minecraft 26.2 mod compilation." >&2
  echo "Current java -version:" >&2
  java -version >&2 || true
  echo >&2
  echo "CachyOS/Arch: sudo pacman -S jdk25-openjdk" >&2
  echo "The script will auto-use /usr/lib/jvm/java-25-openjdk when installed." >&2
  exit 25
fi

if [[ -x ./gradlew ]]; then
  GRADLE=(./gradlew)
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "ERROR: Gradle is not installed and no Gradle wrapper is present." >&2
  echo "CachyOS/Arch: sudo pacman -S gradle" >&2
  exit 26
fi

if command -v python3 >/dev/null 2>&1; then
  PYTHON=(python3)
elif command -v python >/dev/null 2>&1; then
  PYTHON=(python)
else
  echo "ERROR: Python 3 is required for the legacy-contract preflight." >&2
  exit 27
fi

echo "== Static legacy contract =="
"${PYTHON[@]}" tools/verify_legacy_contract.py

echo
echo "== Migration regression and executable GUI composition tests =="
"${PYTHON[@]}" -m unittest discover -s tests -v

echo
echo "== Java / Gradle =="
java -version
echo
"${GRADLE[@]}" --version

echo
echo "== Build core + barrels + chests =="
"${GRADLE[@]}" --no-daemon --stacktrace clean :reinfbarrel:build :reinfchest:build

mkdir -p dist
rm -f dist/*.jar
find reinfbarrel/build/libs reinfchest/build/libs -maxdepth 1 -type f -name '*.jar' \
  ! -name '*-sources.jar' ! -name '*-dev.jar' -print -exec cp -f {} dist/ \;

echo
echo "Build outputs:"
ls -lh dist/*.jar
