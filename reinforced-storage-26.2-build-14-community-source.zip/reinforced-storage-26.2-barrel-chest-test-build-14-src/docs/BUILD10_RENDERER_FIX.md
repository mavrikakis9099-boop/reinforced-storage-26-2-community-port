# Build 10 renderer correction

Build 9 correctly exposed the vanilla `generic_54.png` and `container/slot` resources to the
custom storage screen, but it painted both resources over every slot. Better-GUI styles both
resources, so the result was a doubled border. Build 9 also drew the generic sheet as one block;
that left the player-inventory portion at the vanilla six-row position for taller tiers.

Build 10 follows vanilla `ContainerScreen` composition:

- the top storage section is taken from `generic_54.png` at `u=0,v=0`;
- the player section is taken from `generic_54.png` at `u=0,v=126` after the actual storage height;
- custom rows and columns use the pack-overridable `container/slot` sprite; and
- when a wide tier centers the player inventory, the old left-aligned player-slot art is masked
  before the correctly positioned sprites are submitted.

The inherited menu, slot order, capacities, click handling, Nemo marker and world-data paths are
unchanged. Labels are emitted explicitly in white because Minecraft 26.2 no longer exposes the
older container-label color fields.

This correction needs runtime verification with the Better-GUI pack both disabled and enabled.
After replacing the two mod jars, press F3+T or restart the client before judging the result.
