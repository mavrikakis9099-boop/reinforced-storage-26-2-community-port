# Build 9 — sorting and dark-pack compatibility

## Scope

Build 9 is a client-compatibility revision after the accepted Build 6 migration and the user-tested
Build 8 renderer. It does not change block IDs, item IDs, block-entity IDs, menu IDs, slot counts,
serialization, opener counters, statistics, recipes or hopper behavior.

## Nemo's Inventory Sorting

The current 26.2 Nemo jar (`nemos-inventory-sorting-Fabric-26.2-1.21.3.jar`) identifies supported
modded storage menus by testing a configured Java class name. For Reinforced Storage it tests:

`atonkish.reinfcore.screen.ReinforcedStorageScreenHandler`

Build 9 supplies that exact historical binary name as an interface and makes the existing
`ReinforcedStorageMenu` implement it. Java's `Class.isInstance` accepts an implemented interface,
so Nemo's normal button factories and sorting service handle the menu. No Nemo dependency or direct
Nemo API call is added, and the menu's migration-proven implementation is otherwise unchanged. The
static gate accepts only this one-line marker addition through a normalized Build 6 hash check.

## Resource-pack behavior

The storage screen now samples the active vanilla `generic_54.png` GUI texture and `container/slot`
sprite, so GUI packs can style its panel and slots. The placed chest renderer continues to request
the original `reinfchest:entity/chest/<tier>/<variant>` identifiers; this preserves existing tier
skins and resource-pack behavior.

Minecraft cannot make an arbitrary `minecraft:` chest texture override a different namespace's
`reinfchest:` sprite automatically. Therefore Build 9 includes the optional
`compat_resource_pack/` bridge. It replaces the chest atlas definition with the vanilla chest
directory plus 15 `minecraft:single` aliases, maps reinforced chest item models to
`minecraft:normal`, and maps all reinforced barrel block models (open and closed) to vanilla barrel
texture IDs. The bridge has no PNG files: the highest-priority pack supplying the vanilla IDs wins.

Enable the bridge above the reinforced retexture packs, keep the desired dark/global pack above the
bridge, and press F3+T. Disable the bridge to return to tier-colored reinforced skins.

## Required runtime checks

Use a copy of the accepted disposable world:

1. Install Build 9 barrels/chests, Fabric API 26.2 and Nemo 26.2-1.21.3.
2. Open every reinforced barrel and chest tier, including both halves of double chests. Confirm Nemo
   buttons appear and sorting does not change counts, high slots, names, components or capacities.
3. Enable the bridge with the dark/global pack above it. Check single/double chest textures, chest
   lids, all barrel tiers and open states after F3+T.
4. Disable the bridge, reload, and confirm the existing tier-colored packs still work.
5. Save, restart and re-open the copy; check storage contents and statistics again.
