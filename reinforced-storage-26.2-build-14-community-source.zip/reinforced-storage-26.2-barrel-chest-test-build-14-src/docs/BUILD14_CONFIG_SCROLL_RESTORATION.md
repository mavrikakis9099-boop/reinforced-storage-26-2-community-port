# Build 14 Reinforced Core config and Scroll restoration

## Root cause

Build 13 retained `ReinforcedCoreConfig` only as an in-memory plain object. It had no AutoConfig
schema annotation, serializer registration, Mod Menu entrypoint, configuration screen or Cloth
Config dependency, so there was no `reinfcore.json` persistence path and no Configure button.

The `Single`/`Scroll` enum and model-level row calculation survived the 26.2 port, but Scroll was
not implemented end to end. Storage slots were always positioned as a full-height grid, and the
screen had no scrollbar drawing, wheel handling, drag handling or slot-window updates. This is why
changing the enum alone could not restore the feature.

## Build 14 change

- Restored the upstream-shaped AutoConfig schema with `screenType` and collapsible
  `scrollScreen.rows` fields. Rows are bounded to 6–9 and default to 6.
- Registered a Gson-backed config named `reinfcore`, producing `config/reinfcore.json`.
- Restored the optional Mod Menu entrypoint using the Minecraft 26.2-compatible Mod Menu API.
- Embedded the Minecraft 26.2 Cloth Config dependency inside the matching Reinforced Core jar.
- Added a narrowly scoped slot-coordinate accessor mixin and Scroll viewport logic. Container slot
  order, indices, counts and quick-move ranges are unchanged.
- Added the upstream-style scrollbar track/scroller plus click, wheel and drag behavior.
- Kept Single mode's Build 13 dimensions and standard `generic_54` renderer composition.
- Kept the Nemo screen-handler marker. Nemo's default lower controls follow the centered player
  panel in Single and Scroll modes; configured coordinates remain authoritative.

No mod ID, registry identifier, block state, block entity, menu identifier, inventory size,
serialization path, recipe, tag or world-data meaning was changed. Reinforced Shulker Boxes remain
source/reference-only and are not included as a public jar.

## Automated verification

`tools/build_barrel_chest.sh` runs the following checks before producing the two runtime jars:

- the frozen legacy/world-data contract for migration-proven files and identifiers;
- migration tests for barrel and chest inventory payloads;
- production-screen composition checks for Single and Scroll rows 6 and 9;
- production-menu checks that only the visible Scroll window has interactive slot coordinates;
- scrollbar click, mouse-wheel and drag input checks;
- Nemo lower-row alignment and Build 13 renderer regression checks; and
- Java 25 compilation and remapped Fabric jar construction.

The config schema was also round-tripped through the production Gson/Cloth classes with
`screenType=SCROLL` and `rows=9`. Distribution auditing verifies that both public jars contain the
same Build 14 Core jar, that Core contains the intended Cloth Config jar, and that no public shulker
jar is produced.

## Required live-game checks

Automated tests cannot prove live Minecraft input routing, resource reloads or world save behavior.
Before publishing or opening a canonical world, run this matrix on a disposable copy:

1. Install only the Build 14 barrel/chest jars plus Fabric API; confirm the game starts without a
   separate Core jar. Add Mod Menu and confirm **Mods → Reinforced Core → Configure** opens.
2. Set Single, restart, reopen each barrel/chest tier (including double chests) and confirm the
   unchanged Build 13 layout, player inventory placement and shift-click behavior.
3. Set Scroll with 6 rows, restart, and verify wheel, track click and thumb drag across every tier.
   Repeat with 9 rows and confirm the scrollbar appears only when storage exceeds the viewport.
4. Repeatedly open and close containers, switch Single → Scroll → Single across restarts, and
   confirm `config/reinfcore.json` persists the exact values.
5. Move uniquely named/countable stacks through first, middle and last storage slots; save, exit,
   reload and verify counts, components, names, locks and positions with no loss or duplication.
6. Repeat representative Single and Scroll checks with Nemo's Inventory Sorting: default lower
   controls, upper controls, explicit configured coordinates and shift-click behavior.
7. Repeat representative checks with vanilla resources, the normal reinforced textures and the
   supplied vanilla-texture compatibility bridge under the target resource pack; reload with F3+T.

Build 13 has owner-reported live acceptance for Nemo and the resource-pack matrix. Build 14's new
config persistence and Scroll path remain explicitly pending until the checklist above is completed.
