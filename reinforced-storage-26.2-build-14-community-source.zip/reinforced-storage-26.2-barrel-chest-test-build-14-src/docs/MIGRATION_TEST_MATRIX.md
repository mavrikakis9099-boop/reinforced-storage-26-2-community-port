# Migration Test Matrix

For every tier/type, create fixtures under the original 1.21.11 mods, save/exit cleanly, clone world, then open clone under 26.2 port.

## Inventory payload cases

- empty
- full stacks (64)
- partial stacks (1, 2, 37, 63)
- unstackable tools/armor
- damaged items
- enchanted items
- named/lore items
- potions / component-heavy stacks
- maps / written books where applicable
- items in first, middle and final inventory slot
- every slot populated

## Block behaviour

- place / break / re-place
- silk/default drop semantics where applicable
- hopper insert/extract
- comparator output
- explosion/fire/lava resistance for Netherite tier
- custom name persistence

## Chests

- single chest
- every legal double-chest orientation
- left/right half reload
- chunk unload/reload with double chest
- neighbour removed/replaced

## Shulker boxes

- undyed and every dye colour
- block -> item -> block round trip
- inventory while item is inside player/container inventory
- upgrade recipe preserves full contents
- tooltip integration is secondary and must never affect persistence

## Acceptance criterion

Zero lost stacks, zero changed counts, zero changed item identities/components, zero missing blocks/block entities, and no registry remap warnings for preserved IDs.
