# Build 11 adaptive oversized-screen renderer

**Historical description, superseded by Build 12.** Runtime testing disproved the assumption below
that the inherited screen supplies all empty-slot backgrounds. Build 11 leaves added cells blank
and paints unwanted filler beside the player panel. See `BUILD12_RENDERER_FIX.md` for the correction.

Build 10 corrected the vanilla chest-sheet split and forced white labels, but its extension pass
still had two visual problems on inventories wider or taller than the fixed vanilla 176×222 sheet:
it sampled the header's brown panel for extra storage space, and it drew the player-inventory slice
at the screen's left edge even when the menu centered the player slots under a wide storage grid.

Build 11 keeps the vanilla texture compatibility strategy and makes it dimension-aware:

- the active `textures/gui/container/generic_54.png` remains the source for the native 176-pixel
  portion of the screen;
- the extra storage interior is tiled from a pixel inside the active storage panel, not from the
  brown header, so Better-GUI and similar packs retain their panel tone in every added row/column;
- the vanilla player-inventory slice at `v=126` is placed at the same centered x-offset used by the
  menu's player slots; and
- the screen does not manually submit `container/slot`. `AbstractContainerScreen`'s normal slot
  extraction path renders all menu slots once, including slots outside the fixed sheet, preserving
  the active pack's slot sprite and avoiding double borders.

No larger resource-pack image is required. A vanilla GUI pack has fixed-size assets, so arbitrary
large mod screens cannot inherit unique ornamental pixels that do not exist in the pack. The
renderer therefore preserves the exact native sheet, derives only the neutral storage-panel
extension from that same sheet, and keeps the pack-controlled slot sprite for every slot.

## Runtime acceptance

With Better-GUI disabled and enabled, reload resources and inspect copper, iron, gold, diamond and
netherite barrels and chests, including double chests. Verify:

1. there is one border per slot, with no doubled slot corners;
2. extra rows/columns use the storage panel tone rather than the header brown;
3. the 176×96 player panel and its label are centered under wide storage grids;
4. labels remain white and the Nemo sorting controls still work; and
5. the native-size copper/iron cases remain visually unchanged.

Very large tiers may exceed the available viewport at high GUI scale. That is a separate usability
limit of the preserved legacy layout; lower GUI scale for this acceptance pass. Scrolling remains a
separate migration-sensitive feature and is not silently enabled by this renderer fix.
