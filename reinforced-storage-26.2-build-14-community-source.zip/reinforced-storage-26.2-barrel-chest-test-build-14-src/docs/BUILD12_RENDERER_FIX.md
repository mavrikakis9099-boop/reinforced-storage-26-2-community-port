# Build 12: complete-cell tiling for standard-layout GUI packs

> **Historical note:** Build 13 supersedes this document's statement that Nemo's lower buttons
> could remain screen-edge aligned on wide layouts. Build 13 corrects that placement after Nemo's
> normal widget initialization.

## What changed

Build 11 was a runtime rendering failure despite compiling: it stretched single pixels into the
extended storage area, omitted the extra slot backgrounds, and painted the full screen footprint
beside the player inventory. Those were renderer bugs. Build 12 replaces that composition path.

The screen now owns all slot backgrounds. Minecraft still owns items, hover highlights, tooltips
and mouse/keyboard interaction. The sheet's slot artwork is not overlaid with a separate slot sprite.

| Component | Source in the 256-unit generic_54 sheet | Build 12 behavior |
| --- | --- | --- |
| Header | x=0..175, y=0..16 | Retain 88-unit left/right caps; repeat 18-unit center strips when wide |
| Storage cells | x=7..168, y=17..124 | Tile complete 9×6 blocks; partial blocks end on 18-unit cell boundaries |
| Storage side frames | x=0..6 and 169..175, y=17..124 | Repeat vertically; place the right frame at the actual grid edge |
| Center seam | x=0..175, y=125 | Copy above the player panel |
| Exposed storage shoulders | Top three frame rows, vertically reversed | Close only the exposed left/right edges |
| Player inventory and hotbar | x=0..175, y=126..221 | Copy the entire 176×96 panel once, centered under storage |
| Player-side empty space | None | Submit no background draws |

The header, grid, frame, seam and player pieces are disjoint: even translucent packs receive one
background layer per painted pixel. The existing menu puts storage items at (7,17), whereas the
standard sheet's first cell interior is (8,18). Artwork is aligned to those real item coordinates;
the menu and its saved inventory/slot order are not changed. The inherited rectangular click-outside
behavior is intentionally retained: clicking an unpainted shoulder does not newly become a drop action.

## Supported design convention

The active `minecraft:textures/gui/container/generic_54.png` must retain the vanilla logical layout.
Its physical image may be a uniformly scaled 256×256 atlas (e.g. 512×512 or 1024×1024). Blits use
256 logical texture units, so normalized UVs select the matching physical pixels. Whole cells,
their bevels, colors and alpha are copied; the mod does not guess colors or cache a pack's pixels.
Resource reloads therefore continue to replace the source texture normally.

This covers ordinary vanilla-layout recolors, dark/light themes, repeating slot designs and
uniform higher-resolution replacements. Header ends are preserved, but a painting or gradient
across an entire large sheet may repeat at joins. Layout-changing packs and OptiFine/OptiGUI-style
conditional replacement rules may require their own explicit mod support. A resource pack that
does not override this chest sheet uses the vanilla fallback, as normal. No special assets for
Better-GUI or new built-in light/dark GUI modes are introduced.

The outside/world texture bridge, all 15 legacy chest PNGs, tier counts, menu IDs, click handlers,
statistics and serialized inventories are untouched. The Nemo marker and screen dimensions are
unchanged. Nemo owns its button placement/configuration; Build 12 does not move its widgets or
override user-configured positions. Its player buttons may remain screen-edge aligned on wide layouts.

## Validation and reproducibility

`python3 -m unittest discover -s tests -v` now compiles the **actual production screen and layout
model** with a minimal recording API adapter, executes them, and checks the emitted drawing
coordinates. The adapter intentionally draws no inherited slot background. Tests cover:

- all five barrel, five single-chest and five double-chest layouts;
- all pixels of every 18×18 cell, including added columns and rows;
- unchanged, centered player artwork, including all 36 inventory/hotbar cells;
- full-height left/right borders, no player-side filler, and no overlapping alpha layers;
- unchanged screen dimensions/label positions; and
- logical UV sampling with light, dark, patterned, translucent and 1×/2×/4× synthetic fixtures.

The harness requires a JDK 17+ compiler module; the full mod still requires **Java 25**. It is
not a substitute for compiling against the actual Minecraft/Fabric classes or testing GPU output,
resource-reload hooks and Nemo in Minecraft. The exact Better-GUI-1.9.1 ZIP was not available for
local validation; the attached screenshots were used to identify the failures, not treated as
the original atlas. Do not call synthetic-fixture previews Better-GUI screenshots.

Optional visual QA (Pillow required, not a build dependency):

```bash
python3 tools/preview_gui_composition.py --output /tmp/build12-gui-preview.png
python3 tools/preview_gui_composition.py --texture /path/to/generic_54.png --output /tmp/build12-pack-preview.png
```

The preview replays the recorded production Java draw calls, but it does not launch Minecraft.

Release checks run on 2026-09-13: the legacy-contract scan, shell syntax check, and all **17 tests**
passed. The new draw-map gate was also run against the original Build 11 screen and correctly
rejected its single-pixel expansion. `BUILD12_GUI_PREVIEW.png` records the inspected synthetic
preview. No full Gradle build or Minecraft runtime pass is claimed for this release: this environment
has Java 17, not the Java 25 toolchain required by the mod.

## Owner acceptance

Compile with `bash tools/build_barrel_chest.sh`, install the two matching `port.12` jars in a test
instance, and use a disposable world or copy. With GUI packs disabled and then enabled, inspect
every barrel/chest tier and double chest. Verify every final-row/final-column slot is visible,
hover and item positions align, frames close at the outer edges, and the centered player panel
has no side filler. Sort with Nemo, reload resources, then save/restart and check final-slot items.
Very wide layouts still need a suitable GUI scale; scrolling and capacity changes are out of scope.

## API references

- [Fabric: drawing textures and regions in Minecraft 26.2](https://docs.fabricmc.net/develop/rendering/gui-graphics#drawing-a-portion-of-a-texture)
- [Fabric: container screens and menu responsibilities](https://docs.fabricmc.net/develop/blocks/container-menus)
