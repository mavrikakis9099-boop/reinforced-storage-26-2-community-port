# Upstream status at project start — 2026-09-11

- Aton-Kish repositories are public and MIT licensed.
- Official releases currently stop at Minecraft 1.21.11 for the three mods in the owner's pack.
- Reinforced Chests issue #112 requests Minecraft/Fabric 26.2 support and remains open.
- No public 26.2 release or announced timetable was found at project start.
- A historical migration issue (#67) reported stack counts collapsing to 1 during an older 1.20.4 -> 1.21 migration; this is a regression class we explicitly test against.
