# Build 8 renderer correction — historical validation scope

## Cause

Build 7's `ChestRenderState.customSprite` field is added by NeoForge. It does not exist in the
unmodified Minecraft 26.2 client used by Fabric. The reported javac error is valid; neither a
Java installation change nor a different Gradle version is needed.

Primary references inspected:

- [Mojang 26.2 version metadata](https://piston-meta.mojang.com/v1/packages/bc42e43dfe43d65a2f6c2c1dbb322c75134e51fe/26.2.json)
- [NeoForge's field addition](https://github.com/neoforged/NeoForge/blob/c7de8d9989e9ca844f84288b8378d34ec2609ecd/patches/net/minecraft/client/renderer/blockentity/state/ChestRenderState.java.patch)
- [NeoForge's rendering hook](https://github.com/neoforged/NeoForge/blob/c7de8d9989e9ca844f84288b8378d34ec2609ecd/patches/net/minecraft/client/renderer/blockentity/ChestRenderer.java.patch)

The vanilla client downloaded using Mojang's metadata has SHA-1
`2dc72797acbc1b63fc16a11c4ac393605f453754`, matching Mojang's advertised checksum. That exact jar's
`ChestRenderer`, `ChestRenderState`, `MultiblockChestResources`, `BlockEntityRendererProvider.Context`
and `OrderedSubmitNodeCollector` were inspected to verify the replacement's actual APIs.
No Mojang client jar or decompiled game source is distributed with this source package.

## Checks completed here

- `javac 25.0.4.1 --release 25 -proc:none` compiled `ModChestSprites.java` and
  `ReinforcedChestRenderer.java` against the genuine vanilla 26.2 client, uploaded Build 6 chest/core
  classes, Fabric Loader 0.19.5, JOML 1.10.8, SLF4J 2.0.17 and JSpecify 1.0.0. Exit status: 0.
  No API stubs or NeoForge classes were used.
- Compiled renderer bytecode confirms the single/left/right selection, inherited state extraction,
  vanilla facing transform, cubic lid easing, seasonal fallback, correct submit overload and
  balanced pose stack; it has no `customSprite` field reference.
- The Fabric client initializer is outside that vanilla-only compilation check. Its registration
  method is private in the raw client and is exposed by Fabric's actual
  `fabric-transitive-access-wideners-v1.classtweaker`; that accessibility declaration was verified in Fabric API
  0.160.0+26.2. Full Loom compilation is the authoritative check for this initializer.
- The static compatibility gate passes. All 15 legacy tier PNGs are byte-identical to the original
  chest jar, and the atlas prefixes preserve their identifiers.
- All 171 protected Build 6 runtime files match their frozen SHA-256 values, including barrels,
  core, storage persistence, block entities, recipes, menus and statistics.
- Seven static regression-gate tests pass, including deliberate forbidden-field, persistence,
  statistics, texture, atlas-prefix and unexpected-runtime-file mutations.
- Build script shell syntax checked with `bash -n`.

## Historical status

These checks were the source-side gate for Build 8. The user subsequently compiled and runtime-tested
Build 8 successfully. Build 9 retains that renderer and adds the sorting marker, pack-overridable
inventory GUI, and optional vanilla-texture bridge; its own compile and disposable-world acceptance
steps are recorded in `BARREL_CHEST_TEST_BUILD.md`. The accepted Build 6 migration fixture remains
the data-integrity baseline; no world save was modified here.
