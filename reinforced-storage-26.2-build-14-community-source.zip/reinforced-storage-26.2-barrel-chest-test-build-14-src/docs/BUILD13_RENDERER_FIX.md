# Build 13 Nemo button alignment

Build 12 corrected the storage background composition, but wide containers exposed a separate
alignment problem. Nemo's Inventory Sorting mixin computes its automatic widget positions from the
screen's `imageWidth`. That is correct for its ordinary vanilla screens and keeps the upper
container row at the container edge. Build 12's player panel is deliberately centered at the
vanilla 176-pixel width, so the lower inventory row moved too far right as the storage grid grew.

Build 13 calls the normal screen initialization first, allowing Nemo to create its widgets. It then
examines the public child-widget positions and shifts only widgets at Nemo's four default storage
inventory offsets (`-61`, `-47`, `-33`, `-19`) when they are on the default inventory-button row.
The shift is `(columns - 9) * 9`, which is exactly the player-panel expansion in the existing menu
geometry. This preserves the normal row for 9-column inventories, keeps upper container controls at
the container edge, and leaves explicit Nemo x/y configuration untouched.

The correction is client-only and lives in the existing storage screen. It does not add a Nemo
dependency, alter Nemo, change the menu marker, move any slots, change input handling, or modify
saved inventories. Reinitialization on GUI resize repeats the same calculation.

The executable GUI harness now checks the four lower widget positions across all five barrel tiers,
five single chests and five double chests. It also retains Build 12's complete-cell, frame, player
panel, no-filler, label and resource-layout tests. The harness uses the public 26.2 widget position
API and a minimal recording adapter; full Fabric/Minecraft compilation and in-game acceptance still
require the user's Java 25 client.

For owner testing, open a wide diamond/netherite or double container and verify that the upper Nemo
buttons remain at the storage edge while the lower row sits above the right side of the centered
player inventory. Test with default Nemo configuration first, then verify that a deliberately
customized Nemo position remains where configured.
