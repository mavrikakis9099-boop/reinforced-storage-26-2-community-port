# Build 14 community release

## What this release is

Build 14 is an unofficial Minecraft 26.2 / Fabric compatibility port of the Aton-Kish Reinforced
Barrels and Reinforced Chests projects. It preserves the original mod IDs, registry identifiers,
inventory sizes and saved-data contract while adapting the client GUI to Minecraft 26.2. It also
restores Reinforced Core's Mod Menu configuration and its Single/Scroll layout choice.

The two runtime jars produced by `tools/build_barrel_chest.sh` are:

- `reinforced-barrels-2.7.5+26.2-port.14.jar`
- `reinforced-chests-4.0.0-beta+26.2-port.14.jar`

Each jar contains the matching shared `reinfcore` classes and embedded Cloth Config dependency.
Do not install an old 1.21.11 jar beside these files, and do not install a separate `reinfcore` jar
unless a future release explicitly says otherwise. Mod Menu is optional, but is required to expose
the in-game Configure button.

The `reinfshulker/` module is not part of this release output. It and the exact 1.21.11 reference
jars are retained in the source archive so the compatibility contract can be audited and rerun.

## Installation

1. Back up the world and keep a disposable copy for migration testing.
2. Use Minecraft 26.2 with Fabric Loader 0.19.5, Java 25 and a compatible Fabric API.
3. Install the two Build 14 runtime jars in the instance `mods/` directory.
4. Install a Minecraft 26.2-compatible Mod Menu to edit the Reinforced Core settings in game.
5. If using Nemo's Inventory Sorting, install its Minecraft 26.2-compatible version normally.
6. Optionally install `reinforced-storage-26.2-vanilla-texture-compat.zip` as a resource pack. Put
   the user's dark/global pack above this bridge so its standard vanilla chest/barrel artwork wins;
   reload resources with F3+T. Disable the bridge to use the tier-colored reinforced skins.
7. Test a copy of the world before opening the canonical world.

The vanilla texture bridge contains model/atlas aliases and no PNG artwork. It is intentionally
separate from the jars and does not alter blocks, menus, inventories or world data.

## Compatibility target and limits

The renderer follows the standard Minecraft chest GUI convention: uniformly scaled or
higher-resolution `generic_54` sheets, standard slot cells, transparent artwork and ordinary
stretchable header/frame regions. It is not a universal reinterpretation engine for arbitrary
custom GUI layouts, fixed illustrations, conditional replacement rules or nonstandard UV maps.

Build 14 retains Build 13's renderer and aligns Nemo's automatically placed lower sorting buttons
with the fixed centered player inventory panel in both Single and Scroll mode; explicit Nemo x/y
configuration remains authoritative.

The Reinforced Core screen type defaults to `Single`, which is the unchanged Build 13 full-height
layout. `Scroll` limits the visible storage area to the configured 6–9 rows and supplies a working
scrollbar, wheel input and drag input. The setting is stored in `config/reinfcore.json`.

## Verification status

- Static legacy-contract verification: passed.
- Local executable migration, GUI composition and menu viewport tests: passed.
- Production Java compilation and release-jar audit: passed.
- Owner-reported in-game acceptance remains the Build 13 baseline for Nemo's Inventory Sorting and
  multiple resource packs, including the vanilla texture compatibility bridge.
- Build 14 live-game checks are still required for config persistence, rows 6 and 9, wheel/drag,
  repeated opening, world save/reload and the Nemo/resource-pack matrix. See
  `BUILD14_CONFIG_SCROLL_RESTORATION.md` for the checklist.

The local test harness is not a substitute for a Minecraft/Fabric runtime test. Re-run the build
script on the target machine before publishing compiled jars, and publish the resulting SHA-256
values alongside them.

## License and attribution

The upstream projects identify Aton-Kish as author and use the MIT License. This source archive
keeps the upstream `LICENSE` file and notices. The port is distributed as an unofficial community
compatibility effort; it is not presented as an official upstream version.

## Upstream handoff

The correct public handoff route is the existing 26.2 request in the upstream Reinforced Chests
repository: <https://github.com/Aton-Kish/reinforced-chests/issues/112>. After a public download URL
has been attached to the release, use this short note:

> Hi Aton-Kish — I prepared an unofficial Minecraft 26.2 / Fabric compatibility port for
> Reinforced Barrels and Reinforced Chests, preserving the original IDs and saved-data contract.
> Build 14 has passed the included static, migration, GUI/menu and build checks. It restores the
> Reinforced Core Mod Menu configuration and Single/Scroll layouts while preserving Build 13's
> renderer and compatibility contract. It is clearly marked unofficial, retains the MIT attribution,
> and does not include the shulker-box jar. Download/source: [public release URL].
> Please treat it as a community handoff for review, not an official upstream release.
