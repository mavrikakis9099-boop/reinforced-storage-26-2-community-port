Reinforced Storage 26.2 — Vanilla Texture Compatibility
=========================================================

This optional client resource pack makes the placed reinforced chests and barrels consume the
normal Minecraft chest/barrel texture IDs.  Any resource pack that changes those vanilla textures
then changes the reinforced storage appearance too, including dark resource packs.

Install
-------

1. Put this folder (or the supplied ZIP) in the 26.2 instance's resourcepacks directory.
2. Enable it above the reinforced chest/barrel retexture packs and above any pack that replaces
   the chest atlas or the reinforced model files.
3. Keep the dark/global resource pack above this bridge when it supplies the vanilla chest or
   barrel textures you want to see.
4. Press F3+T after changing the order.

The bridge intentionally contains no PNG files.  It aliases the reinforced chest atlas sprites
and barrel model texture references to vanilla IDs, so the highest-priority pack supplying those
vanilla IDs wins.  It does not change blocks, items, menus, inventories or world data.

To return to the tier-colored reinforced skins, disable this bridge and reload resources.  The
original ReinforcedChests_Retextured.zip and ReinforcedBarrels_Retextured.zip packs can then be
used normally.

The bridge targets Minecraft 26.2 (resource-pack format 88) and is not a mod jar.
