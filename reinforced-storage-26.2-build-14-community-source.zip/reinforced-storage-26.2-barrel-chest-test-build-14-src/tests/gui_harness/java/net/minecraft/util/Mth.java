package net.minecraft.util;

public final class Mth {
    private Mth() {
    }

    public static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
