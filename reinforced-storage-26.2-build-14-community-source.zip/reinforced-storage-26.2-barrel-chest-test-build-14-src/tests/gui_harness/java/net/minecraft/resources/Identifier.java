package net.minecraft.resources;
public record Identifier(String value) {
    public static Identifier withDefaultNamespace(String path) {
        return new Identifier("minecraft:" + path);
    }
}
