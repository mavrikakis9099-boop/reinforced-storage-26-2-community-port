package net.minecraft.client.gui.components.events;

/** Minimal 26.2 listener marker used by the executable GUI composition harness. */
public interface GuiEventListener {
}
