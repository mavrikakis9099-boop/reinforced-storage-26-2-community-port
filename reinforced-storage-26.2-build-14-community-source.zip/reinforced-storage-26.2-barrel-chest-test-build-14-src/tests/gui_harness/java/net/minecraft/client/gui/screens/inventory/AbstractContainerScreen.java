package net.minecraft.client.gui.screens.inventory;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/** Only the API surface used by the production screen; no slot-background drawing. */
public class AbstractContainerScreen<T> {
    protected final T menu;
    protected final Component title;
    protected final Component playerInventoryTitle = Component.literal("Inventory");
    protected final Object font = new Object();
    protected final int imageWidth;
    protected final int imageHeight;
    protected int titleLabelX, titleLabelY, inventoryLabelX, inventoryLabelY;
    protected int leftPos = 20, topPos = 30;
    private final List<GuiEventListener> children = new ArrayList<>();

    public AbstractContainerScreen(T menu, Inventory inventory, Component title, int width, int height) {
        this.menu = menu;
        this.title = title;
        this.imageWidth = width;
        this.imageHeight = height;
    }

    public int getImageWidth() { return imageWidth; }
    public int getImageHeight() { return imageHeight; }
    protected void init() {
        // Simulate Nemo's four default storage-inventory buttons. The production screen's
        // post-init correction must move these with its centered player panel.
        int y = topPos + inventoryLabelY - 2;
        for (int rightOffset : new int[] {-61, -47, -33, -19}) {
            children.add(new AbstractWidget(leftPos + imageWidth + rightOffset, y, 11, 11));
        }
        // A deliberately customized x position must remain untouched by the production fix.
        children.add(new AbstractWidget(leftPos + imageWidth - 5, y, 11, 11));
    }
    public List<? extends GuiEventListener> children() { return children; }
    public void extractBackground(GuiGraphicsExtractor graphics, int x, int y, float delta) {}
    protected void extractLabels(GuiGraphicsExtractor graphics, int x, int y) {}
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) { return false; }
    public boolean mouseClicked(MouseButtonEvent event, boolean doubled) { return false; }
    public boolean mouseReleased(MouseButtonEvent event) { return false; }
    public boolean mouseDragged(MouseButtonEvent event, double offsetX, double offsetY) { return false; }
}
