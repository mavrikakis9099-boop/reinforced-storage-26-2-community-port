package net.minecraft.client.gui.components;

import net.minecraft.client.gui.components.events.GuiEventListener;

/** Minimal 26.2 widget position API used by the production compatibility correction. */
public class AbstractWidget implements GuiEventListener {
    private int x;
    private final int y;
    private final int width;
    private final int height;

    public AbstractWidget(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public void setX(int x) { this.x = x; }
}
