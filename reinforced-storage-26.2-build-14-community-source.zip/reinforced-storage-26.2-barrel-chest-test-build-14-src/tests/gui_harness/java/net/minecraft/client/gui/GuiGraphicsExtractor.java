package net.minecraft.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Recording adapter, NOT a Minecraft renderer or API compatibility proof. */
public final class GuiGraphicsExtractor {
    public final List<int[]> blits = new ArrayList<>();
    public final List<int[]> scrollbarBlits = new ArrayList<>();
    public final List<int[]> sprites = new ArrayList<>();
    public final List<int[]> labels = new ArrayList<>();

    public void blit(Object pipeline, Identifier texture, int x, int y, float u, float v,
            int width, int height, int regionWidth, int regionHeight, int textureWidth, int textureHeight) {
        int[] operation = new int[] {x, y, (int) u, (int) v, width, height,
                regionWidth, regionHeight, textureWidth, textureHeight};
        if (texture.value().equals("minecraft:textures/gui/container/generic_54.png")) {
            blits.add(operation);
        } else if (texture.value().equals(
                "minecraft:textures/gui/container/creative_inventory/tab_items.png")) {
            scrollbarBlits.add(operation);
        } else {
            throw new AssertionError("Unexpected texture " + texture);
        }
    }

    public void blitSprite(Object pipeline, Identifier texture, int x, int y, int width, int height) {
        if (!texture.value().equals("minecraft:container/creative_inventory/scroller")) {
            throw new AssertionError("Unexpected sprite " + texture);
        }
        sprites.add(new int[] {x, y, width, height});
    }

    public void text(Object font, Component text, int x, int y, int color, boolean shadow) {
        labels.add(new int[] {x, y, color});
    }
}
