package net.minecraft.world.item;
public final class Item {}
