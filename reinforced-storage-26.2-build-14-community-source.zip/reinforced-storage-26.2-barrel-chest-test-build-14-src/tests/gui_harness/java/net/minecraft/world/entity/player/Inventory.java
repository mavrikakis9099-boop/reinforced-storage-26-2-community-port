package net.minecraft.world.entity.player;
public final class Inventory {}
