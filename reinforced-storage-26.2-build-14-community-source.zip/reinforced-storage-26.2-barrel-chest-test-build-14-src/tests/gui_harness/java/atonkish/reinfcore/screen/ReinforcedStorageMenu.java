package atonkish.reinfcore.screen;
import atonkish.reinfcore.ReinforcedCoreMod;
import atonkish.reinfcore.util.ReinforcedStorageScreenModel;
import atonkish.reinfcore.util.ReinforcedStorageScreenType;
import atonkish.reinfcore.util.ReinforcingMaterial;
public final class ReinforcedStorageMenu {
    private final ReinforcingMaterial material;
    private final boolean doubleBlock;
    private final int columns;
    private final int visibleRows;
    private int lastStartRow;
    public ReinforcedStorageMenu(ReinforcingMaterial material, boolean doubleBlock) {
        this.material = material;
        this.doubleBlock = doubleBlock;
        int size = material.getSize() * (doubleBlock ? 2 : 1);
        this.columns = ReinforcedStorageScreenModel.getContainerInventoryColumns(size);
        this.visibleRows = ReinforcedStorageScreenModel.getContainerInventoryRows(size, columns);
    }
    public ReinforcingMaterial getMaterial() { return material; }
    public boolean isDoubleBlock() { return doubleBlock; }
    public int getColumns() { return columns; }
    public int getVisibleRows() { return visibleRows; }
    public Container getContainer() { return new Container(material.getSize() * (doubleBlock ? 2 : 1)); }
    public boolean shouldShowScrollbar() {
        int totalRows = (getContainer().getContainerSize() + columns - 1) / columns;
        return ReinforcedCoreMod.CONFIG.screenType == ReinforcedStorageScreenType.SCROLL
                && totalRows > visibleRows;
    }
    public void scrollItems(float position) {
        int totalRows = (getContainer().getContainerSize() + columns - 1) / columns;
        this.lastStartRow = Math.round(position * Math.max(0, totalRows - visibleRows));
    }
    public int getLastStartRow() { return lastStartRow; }
    public record Container(int size) { public int getContainerSize() { return size; } }
}
