package atonkish.reinfcore;
import atonkish.reinfcore.util.ReinforcedStorageScreenType;
public final class ReinforcedCoreMod {
    public static final Config CONFIG = new Config();
    public static final class Config {
        public ReinforcedStorageScreenType screenType = ReinforcedStorageScreenType.SINGLE;
        public final Scroll scrollScreen = new Scroll();
    }
    public static final class Scroll { public int rows = 6; }
}
