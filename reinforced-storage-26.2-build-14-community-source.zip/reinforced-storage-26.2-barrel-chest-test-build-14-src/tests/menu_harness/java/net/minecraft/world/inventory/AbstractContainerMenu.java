package net.minecraft.world.inventory;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public abstract class AbstractContainerMenu {
    protected final List<Slot> slots = new ArrayList<>();

    protected AbstractContainerMenu(MenuType<?> type, int containerId) {
    }

    protected Slot addSlot(Slot slot) {
        slots.add(slot);
        return slot;
    }

    public Slot getSlot(int index) {
        return slots.get(index);
    }

    public int slotsSize() {
        return slots.size();
    }

    protected boolean moveItemStackTo(ItemStack stack, int start, int end, boolean reverse) {
        return true;
    }

    public abstract boolean stillValid(Player player);
    public abstract ItemStack quickMoveStack(Player player, int index);
    public void removed(Player player) { }
}
