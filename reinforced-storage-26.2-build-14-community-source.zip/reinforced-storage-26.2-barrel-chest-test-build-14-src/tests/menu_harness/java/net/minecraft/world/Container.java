package net.minecraft.world;

import net.minecraft.world.entity.player.Player;

public interface Container {
    int getContainerSize();
    default void startOpen(Player player) { }
    default void stopOpen(Player player) { }
    default boolean stillValid(Player player) { return true; }
}
