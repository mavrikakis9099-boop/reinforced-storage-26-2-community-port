package net.minecraft.world.entity.player;

import net.minecraft.world.Container;

public final class Inventory implements Container {
    public static final int INVENTORY_SIZE = 36;
    public final Player player = new Player();

    @Override
    public int getContainerSize() {
        return INVENTORY_SIZE;
    }
}
