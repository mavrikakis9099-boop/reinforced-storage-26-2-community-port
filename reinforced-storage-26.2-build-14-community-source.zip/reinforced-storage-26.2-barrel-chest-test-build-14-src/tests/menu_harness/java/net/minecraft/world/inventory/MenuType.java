package net.minecraft.world.inventory;

public class MenuType<T> {
}
