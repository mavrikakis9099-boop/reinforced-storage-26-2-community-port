package net.minecraft.world;

public final class SimpleContainer implements Container {
    private final int size;

    public SimpleContainer(int size) {
        this.size = size;
    }

    @Override
    public int getContainerSize() {
        return size;
    }
}
