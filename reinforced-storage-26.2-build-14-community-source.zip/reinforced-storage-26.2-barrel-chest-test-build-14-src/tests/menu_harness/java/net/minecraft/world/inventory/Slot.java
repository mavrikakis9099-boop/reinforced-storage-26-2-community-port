package net.minecraft.world.inventory;

import atonkish.reinfcore.mixin.SlotAccessor;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

public final class Slot implements SlotAccessor {
    public final Container container;
    private final int containerSlot;
    public int x;
    public int y;
    private ItemStack stack = ItemStack.EMPTY;

    public Slot(Container container, int containerSlot, int x, int y) {
        this.container = container;
        this.containerSlot = containerSlot;
        this.x = x;
        this.y = y;
    }

    public boolean hasItem() { return !stack.isEmpty(); }
    public ItemStack getItem() { return stack; }
    public void set(ItemStack stack) { this.stack = stack; }
    public void setChanged() { }
    public int getContainerSlot() { return containerSlot; }
    @Override public void reinfcore$setX(int x) { this.x = x; }
    @Override public void reinfcore$setY(int y) { this.y = y; }
}
