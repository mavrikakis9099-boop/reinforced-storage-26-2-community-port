package net.minecraft.world.item;

public class ItemStack {
    public static final ItemStack EMPTY = new ItemStack(true);
    private final boolean empty;

    public ItemStack() {
        this(false);
    }

    private ItemStack(boolean empty) {
        this.empty = empty;
    }

    public ItemStack copy() { return empty ? EMPTY : new ItemStack(); }
    public boolean isEmpty() { return empty; }
}
