package atonkish.reinfcore.mixin;

public interface SlotAccessor {
    void reinfcore$setX(int x);
    void reinfcore$setY(int y);
}
