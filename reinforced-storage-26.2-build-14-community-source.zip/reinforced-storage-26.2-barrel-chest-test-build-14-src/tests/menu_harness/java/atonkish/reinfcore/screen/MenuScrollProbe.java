package atonkish.reinfcore.screen;

import atonkish.reinfcore.ReinforcedCoreMod;
import atonkish.reinfcore.util.ReinforcedStorageScreenType;
import atonkish.reinfcore.util.ReinforcingMaterial;

import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public final class MenuScrollProbe {
    public static void main(String[] args) {
        int tierSize = Integer.parseInt(args[0]);
        boolean doubleBlock = Boolean.parseBoolean(args[1]);
        ReinforcedCoreMod.CONFIG.screenType = ReinforcedStorageScreenType.valueOf(args[2]);
        ReinforcedCoreMod.CONFIG.scrollScreen.rows = Integer.parseInt(args[3]);

        ReinforcingMaterial material = new ReinforcingMaterial("test", tierSize, null);
        int storageSize = tierSize * (doubleBlock ? 2 : 1);
        SimpleContainer storage = new SimpleContainer(storageSize);
        ReinforcedStorageMenu menu = new ReinforcedStorageMenu(
                null, material, doubleBlock, 1, new Inventory(), storage);

        System.out.println("LAYOUT " + menu.getColumns() + " " + menu.getVisibleRows()
                + " " + (menu.shouldShowScrollbar() ? 1 : 0));
        emitSlot("FIRST", menu.getSlot(0));
        emitSlot("VISIBLE_END", menu.getSlot(Math.min(storageSize, menu.getColumns()
                * menu.getVisibleRows()) - 1));
        if (storageSize > menu.getColumns() * menu.getVisibleRows()) {
            emitSlot("HIDDEN_FIRST", menu.getSlot(menu.getColumns() * menu.getVisibleRows()));
        }
        emitSlot("PLAYER_FIRST", menu.getSlot(storageSize));
        emitSlot("HOTBAR_FIRST", menu.getSlot(storageSize + 27));

        menu.scrollItems(1.0f);
        emitSlot("AFTER_FIRST", menu.getSlot(0));
        int lastWindowStart = storageSize - menu.getColumns() * menu.getVisibleRows();
        if (lastWindowStart >= 0) {
            emitSlot("AFTER_WINDOW_FIRST", menu.getSlot(lastWindowStart));
        }
        emitSlot("AFTER_LAST", menu.getSlot(storageSize - 1));

        int badIndices = 0;
        for (int index = 0; index < storageSize; index++) {
            Slot slot = menu.getSlot(index);
            if (slot.container != storage || slot.getContainerSlot() != index) {
                badIndices++;
            }
        }
        System.out.println("IDENTITY " + badIndices + " " + menu.slotsSize());
    }

    private static void emitSlot(String label, Slot slot) {
        System.out.println(label + " " + slot.x + " " + slot.y);
    }
}
