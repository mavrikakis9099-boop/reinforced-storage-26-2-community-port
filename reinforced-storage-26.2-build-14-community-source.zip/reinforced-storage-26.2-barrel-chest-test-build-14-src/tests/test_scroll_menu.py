"""Execute the production menu against recording stubs to verify slot-window semantics."""

from functools import lru_cache
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOT = ROOT / "reinfcore/src/main/java"


def compile_probe(output_dir):
    java = shutil.which("java")
    if java is None:
        raise RuntimeError("Scroll menu tests require a JDK.")
    sources = list((ROOT / "tests/menu_harness/java").rglob("*.java"))
    sources += [JAVA_ROOT / ("atonkish/reinfcore/" + path) for path in (
        "screen/ReinforcedStorageMenu.java",
        "screen/ReinforcedStorageScreenHandler.java",
        "util/ReinforcedStorageScreenModel.java",
        "util/ReinforcedStorageScreenType.java",
        "util/ReinforcingMaterial.java",
        "util/math/Point2i.java",
    )]
    subprocess.run(
        [java, "com.sun.tools.javac.Main", "--release", "17", "-d", str(output_dir),
         *map(str, sources)],
        check=True,
        capture_output=True,
        text=True,
    )
    return java


def parse_probe(output):
    parsed = {}
    for line in output.splitlines():
        label, *values = line.split()
        parsed[label] = tuple(map(int, values))
    return parsed


class ScrollMenuTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="reinforced-menu-java-")
        cls.addClassCleanup(cls.temp.cleanup)
        cls.java = compile_probe(cls.temp.name)

    @classmethod
    @lru_cache(maxsize=None)
    def probe(cls, mode, rows):
        result = subprocess.run(
            [cls.java, "-cp", cls.temp.name,
             "atonkish.reinfcore.screen.MenuScrollProbe",
             "108", "true", mode, str(rows)],
            check=True,
            capture_output=True,
            text=True,
        )
        return parse_probe(result.stdout)

    def test_scroll_rows_6_moves_only_the_visible_storage_window(self):
        probe = self.probe("SCROLL", 6)
        self.assertEqual(probe["LAYOUT"], (9, 6, 1))
        self.assertEqual(probe["FIRST"], (7, 17))
        self.assertEqual(probe["VISIBLE_END"], (151, 107))
        self.assertEqual(probe["HIDDEN_FIRST"], (-(2 ** 31), -(2 ** 31)))
        self.assertEqual(probe["PLAYER_FIRST"], (7, 139))
        self.assertEqual(probe["HOTBAR_FIRST"], (7, 197))
        self.assertEqual(probe["AFTER_FIRST"], (-(2 ** 31), -(2 ** 31)))
        self.assertEqual(probe["AFTER_WINDOW_FIRST"], (7, 17))
        self.assertEqual(probe["AFTER_LAST"], (151, 107))
        self.assertEqual(probe["IDENTITY"], (0, 252))

    def test_scroll_rows_9_moves_only_the_visible_storage_window(self):
        probe = self.probe("SCROLL", 9)
        self.assertEqual(probe["LAYOUT"], (9, 9, 1))
        self.assertEqual(probe["VISIBLE_END"], (151, 161))
        self.assertEqual(probe["HIDDEN_FIRST"], (-(2 ** 31), -(2 ** 31)))
        self.assertEqual(probe["PLAYER_FIRST"], (7, 193))
        self.assertEqual(probe["HOTBAR_FIRST"], (7, 251))
        self.assertEqual(probe["AFTER_WINDOW_FIRST"], (7, 17))
        self.assertEqual(probe["AFTER_LAST"], (151, 161))
        self.assertEqual(probe["IDENTITY"], (0, 252))

    def test_single_layout_coordinates_and_slot_identity_do_not_change(self):
        probe = self.probe("SINGLE", 6)
        self.assertEqual(probe["LAYOUT"], (24, 9, 0))
        self.assertEqual(probe["FIRST"], (7, 17))
        self.assertEqual(probe["VISIBLE_END"], (421, 161))
        self.assertNotIn("HIDDEN_FIRST", probe)
        self.assertEqual(probe["PLAYER_FIRST"], (142, 193))
        self.assertEqual(probe["HOTBAR_FIRST"], (142, 251))
        self.assertEqual(probe["AFTER_FIRST"], (7, 17))
        self.assertEqual(probe["AFTER_WINDOW_FIRST"], (7, 17))
        self.assertEqual(probe["AFTER_LAST"], (421, 161))
        self.assertEqual(probe["IDENTITY"], (0, 252))


if __name__ == "__main__":
    unittest.main()
