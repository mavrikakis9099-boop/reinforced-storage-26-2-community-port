"""Negative tests for the static visual-build gate; these are not Minecraft runtime tests."""
from contextlib import redirect_stdout
import importlib.util
from io import StringIO
from pathlib import Path
import shutil
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("contract", ROOT / "tools/verify_legacy_contract.py")
CONTRACT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CONTRACT)
RENDERER = "reinfchest/src/main/java/atonkish/reinfchest/client/render/blockentity/ReinforcedChestRenderer.java"
TEXTURE_BRIDGE_ATLAS = "compat_resource_pack/assets/minecraft/atlases/chests.json"


class VisualContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="reinforced-visual-contract-")
        self.root = Path(self.temp.name) / "fixture"
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns(
            ".gradle", "build", "dist", "__pycache__", "build-barrel-chest.log"
        ))
        CONTRACT.ROOT = self.root
        CONTRACT.LEGACY = self.root / "legacy_reference"
        CONTRACT.TEXTURE_COMPAT_PACK = self.root / "compat_resource_pack"
        self.addCleanup(self.temp.cleanup)

    def check(self, message=None):
        output = StringIO()
        with redirect_stdout(output):
            if message is None:
                self.assertEqual(CONTRACT.main(), 0)
            else:
                with self.assertRaises(SystemExit):
                    CONTRACT.main()
        if message:
            self.assertIn(message, output.getvalue())

    def test_unchanged_build_passes(self):
        self.check()

    def test_rejects_neoforge_hook(self):
        path = self.root / RENDERER
        path.write_text(path.read_text() + "\n// state.customSprite\n")
        self.check("NeoForge-only")

    def test_rejects_changed_persistence_source(self):
        path = self.root / "reinfchest/src/main/java/atonkish/reinfchest/block/entity/ReinforcedChestBlockEntity.java"
        path.write_text(path.read_text() + "\n// unintended change\n")
        self.check("migration-proven file changed")

    def test_rejects_changed_original_texture(self):
        path = self.root / "reinfchest/src/main/resources/assets/reinfchest/textures/entity/chest/gold/left.png"
        path.write_bytes(path.read_bytes() + b"changed")
        self.check("legacy chest texture changed")

    def test_rejects_wrong_atlas_prefix(self):
        path = self.root / "reinfchest/src/main/resources/assets/minecraft/atlases/chests.json"
        path.write_text(path.read_text().replace('"prefix": "entity/chest/copper/"', '"prefix": "wrong/"'))
        self.check("chest atlas prefix")

    def test_rejects_added_runtime_file(self):
        path = self.root / "reinfcore/src/main/java/Unexpected.java"
        path.write_text("class Unexpected {}\n")
        self.check("unexpected file outside")

    def test_rejects_changed_statistics(self):
        path = self.root / "reinfchest/src/main/java/atonkish/reinfchest/stat/ModStats.java"
        path.write_text(path.read_text() + "\n// unintended stat change\n")
        self.check("migration-proven file changed")

    def test_rejects_changed_texture_bridge(self):
        path = self.root / TEXTURE_BRIDGE_ATLAS
        path.write_text(path.read_text().replace(
            '"sprite": "reinfchest:entity/chest/copper/single"',
            '"sprite": "reinfchest:entity/chest/iron/single"',
            1,
        ))
        self.check("chest aliases")

    def test_rejects_manual_slot_overdraw(self):
        path = self.root / "reinfcore/src/main/java/atonkish/reinfcore/client/gui/screen/ReinforcedStorageScreen.java"
        path.write_text(path.read_text() + "\n// graphics.blitSprite(RenderPipelines.GUI_TEXTURED, slotSprite);\n")
        self.check("overlays separate slot sprites")


if __name__ == "__main__":
    unittest.main()
