package atonkish.reinfbarrel.block;

import atonkish.reinfbarrel.block.entity.ReinforcedBarrelBlockEntity;
import atonkish.reinfbarrel.stat.ModStats;
import atonkish.reinfcore.util.ReinforcingMaterial;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;

import org.jetbrains.annotations.Nullable;

/** Vanilla barrel behavior with a tiered, migration-compatible block entity. */
public final class ReinforcedBarrelBlock extends BarrelBlock {
    private final ReinforcingMaterial material;

    public ReinforcedBarrelBlock(ReinforcingMaterial material, BlockBehaviour.Properties properties) {
        super(properties);
        this.material = material;
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ReinforcedBarrelBlockEntity(material, pos, state);
    }

    /** Matches the original mod's barrel interaction so its per-tier statistic keeps advancing. */
    @Override
    public InteractionResult useWithoutItem(
            BlockState state,
            Level level,
            BlockPos pos,
            Player player,
            BlockHitResult hitResult
    ) {
        if (level instanceof ServerLevel serverLevel
                && level.getBlockEntity(pos) instanceof BarrelBlockEntity barrel) {
            player.openMenu(barrel);
            player.awardStat(ModStats.OPEN_REINFORCED_BARREL_MAP.get(material));
            PiglinAi.angerNearbyPiglins(serverLevel, player, true);
        }
        return InteractionResult.SUCCESS;
    }

    public ReinforcingMaterial getMaterial() {
        return material;
    }
}
