package atonkish.reinfbarrel.block.entity;

import java.util.List;

import atonkish.reinfbarrel.mixin.BlockEntityAccessor;
import atonkish.reinfcore.screen.ReinforcedStorageMenu;
import atonkish.reinfcore.screen.ReinforcedStorageMenuTypes;
import atonkish.reinfcore.util.ReinforcingMaterial;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ContainerUser;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.ContainerOpenersCounter;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 26.2 counterpart of the legacy reinforced barrel block entity.
 *
 * <p>It deliberately preserves the two migration-sensitive tricks used by 2.7.5: construct as a
 * vanilla barrel then swap to the exact {@code reinfbarrel:*} block-entity type, and use a custom
 * opener counter that recognises ReinforcedStorageMenu rather than vanilla ChestMenu.</p>
 */
public final class ReinforcedBarrelBlockEntity extends BarrelBlockEntity {
    private final ReinforcingMaterial cachedMaterial;

    private final ContainerOpenersCounter reinforcedOpenersCounter = new ContainerOpenersCounter() {
        @Override
        protected void onOpen(Level level, BlockPos pos, BlockState state) {
            playBarrelSound(level, pos, SoundEvents.BARREL_OPEN);
            updateOpenState(level, pos, state, true);
        }

        @Override
        protected void onClose(Level level, BlockPos pos, BlockState state) {
            playBarrelSound(level, pos, SoundEvents.BARREL_CLOSE);
            updateOpenState(level, pos, state, false);
        }

        @Override
        protected void openerCountChanged(Level level, BlockPos pos, BlockState state, int previous, int current) {
            // Legacy implementation intentionally does nothing here.
        }

        @Override
        public boolean isOwnContainer(Player player) {
            if (player.containerMenu instanceof ReinforcedStorageMenu menu) {
                return menu.getContainer() == ReinforcedBarrelBlockEntity.this;
            }
            return false;
        }
    };

    public ReinforcedBarrelBlockEntity(ReinforcingMaterial material, BlockPos pos, BlockState state) {
        super(pos, state);
        this.cachedMaterial = material;

        var customType = ModBlockEntityTypes.REINFORCED_BARREL_MAP.get(material);
        if (customType == null) {
            throw new IllegalStateException("Reinforced barrel block entity type not registered for " + material);
        }
        ((BlockEntityAccessor) (Object) this).reinfbarrel$setType(customType);

        // Legacy 2.7.5 does the same immediately after the vanilla constructor. Loading occurs
        // afterwards, so vanilla container deserialization fills these exact tier-sized slots.
        setItems(NonNullList.withSize(material.getSize(), ItemStack.EMPTY));
    }

    @Override
    public int getContainerSize() {
        return cachedMaterial.getSize();
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.reinfbarrel." + cachedMaterial.getName() + "Barrel");
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        var menuType = ReinforcedStorageMenuTypes.SINGLE_MAP.get(cachedMaterial);
        if (menuType == null) {
            throw new IllegalStateException("Menu type not registered for " + cachedMaterial);
        }
        return new ReinforcedStorageMenu(menuType, cachedMaterial, false, containerId, inventory, this);
    }

    @Override
    public void startOpen(ContainerUser containerUser) {
        if (isRemoved()) {
            return;
        }
        var living = containerUser.getLivingEntity();
        if (living.isSpectator() || level == null) {
            return;
        }
        reinforcedOpenersCounter.incrementOpeners(
                living, level, worldPosition, getBlockState(), containerUser.getContainerInteractionRange());
    }

    @Override
    public void stopOpen(ContainerUser containerUser) {
        if (isRemoved()) {
            return;
        }
        var living = containerUser.getLivingEntity();
        if (living.isSpectator() || level == null) {
            return;
        }
        reinforcedOpenersCounter.decrementOpeners(living, level, worldPosition, getBlockState());
    }

    @Override
    public List<ContainerUser> getEntitiesWithContainerOpen() {
        if (level == null) {
            return List.of();
        }
        return reinforcedOpenersCounter.getEntitiesWithContainerOpen(level, worldPosition);
    }

    @Override
    public void recheckOpen() {
        if (!isRemoved() && level != null) {
            reinforcedOpenersCounter.recheckOpeners(level, worldPosition, getBlockState());
        }
    }

    private static void updateOpenState(Level level, BlockPos pos, BlockState state, boolean open) {
        level.setBlock(pos, state.setValue(BarrelBlock.OPEN, open), 3);
    }

    private static void playBarrelSound(Level level, BlockPos pos, net.minecraft.sounds.SoundEvent sound) {
        level.playSound(null, pos, sound, SoundSource.BLOCKS, 0.5F, 1.0F);
    }

    public ReinforcingMaterial getMaterial() {
        return cachedMaterial;
    }
}
