package atonkish.reinfbarrel.mixin;

import java.util.Set;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Migration-critical accessor.
 *
 * <p>The legacy 2.7.5 mod adds every reinforced barrel block to vanilla's BARREL block-entity
 * type before constructing its subclass. Minecraft validates the block state in the vanilla
 * BarrelBlockEntity constructor, so the 26.2 port must preserve that behavior.</p>
 */
@Mixin(BlockEntityType.class)
public interface BlockEntityTypeAccessor {
    @Accessor("validBlocks")
    Set<Block> reinfbarrel$getValidBlocks();

    @Mutable
    @Accessor("validBlocks")
    void reinfbarrel$setValidBlocks(Set<Block> blocks);
}
