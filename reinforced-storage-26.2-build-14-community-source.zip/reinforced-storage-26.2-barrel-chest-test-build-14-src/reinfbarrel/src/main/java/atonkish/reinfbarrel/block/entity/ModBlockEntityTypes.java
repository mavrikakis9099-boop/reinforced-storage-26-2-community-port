package atonkish.reinfbarrel.block.entity;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.mixin.BlockEntityTypeAccessor;
import atonkish.reinfcore.util.ReinforcingMaterial;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntityTypes;

/** Exact legacy block-entity identifiers for existing-world resolution. */
public final class ModBlockEntityTypes {
    public static final Map<ReinforcingMaterial, BlockEntityType<ReinforcedBarrelBlockEntity>> REINFORCED_BARREL_MAP = new LinkedHashMap<>();

    private ModBlockEntityTypes() {
    }

    public static BlockEntityType<ReinforcedBarrelBlockEntity> registerMaterial(ReinforcingMaterial material) {
        return REINFORCED_BARREL_MAP.computeIfAbsent(material, key -> {
            Identifier id = Identifier.fromNamespaceAndPath(ReinforcedBarrelsMod.MOD_ID, key.getName() + "_barrel");
            Block block = ModBlocks.REINFORCED_BARREL_MAP.get(key);
            if (block == null) {
                throw new IllegalStateException("Block must be registered before its block entity: " + id);
            }

            BlockEntityType<ReinforcedBarrelBlockEntity> type = FabricBlockEntityTypeBuilder
                    .create((pos, state) -> new ReinforcedBarrelBlockEntity(key, pos, state), block)
                    .build();
            BlockEntityType<ReinforcedBarrelBlockEntity> registered =
                    Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, id, type);

            // Legacy 2.7.5 explicitly adds reinforced barrel blocks to vanilla BARREL's valid
            // block set. BarrelBlockEntity's public constructor starts as the vanilla BARREL type
            // and BlockEntity validates the supplied state before our subclass can swap its type.
            BlockEntityTypeAccessor accessor = (BlockEntityTypeAccessor) (Object) BlockEntityTypes.BARREL;
            Set<Block> validBlocks = new HashSet<>(accessor.reinfbarrel$getValidBlocks());
            validBlocks.add(block);
            accessor.reinfbarrel$setValidBlocks(validBlocks);

            return registered;
        });
    }
}
