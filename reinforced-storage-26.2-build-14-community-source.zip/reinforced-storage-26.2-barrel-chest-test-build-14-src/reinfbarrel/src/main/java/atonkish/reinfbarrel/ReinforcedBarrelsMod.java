package atonkish.reinfbarrel;

import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.block.entity.ModBlockEntityTypes;
import atonkish.reinfbarrel.stat.ModStats;
import atonkish.reinfbarrel.util.ReinforcingMaterialSettings;
import atonkish.reinfcore.screen.ReinforcedStorageMenuTypes;

import net.fabricmc.api.ModInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Compatibility-first Fabric 26.2 port of Aton-Kish Reinforced Barrels. */
public final class ReinforcedBarrelsMod implements ModInitializer {
    public static final String MOD_ID = "reinfbarrel";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Order is deliberate: material -> menu -> block/item -> block entity.
        // Existing-world block/entity IDs must be present before a save is opened.
        for (ReinforcingMaterialSettings settings : ReinforcingMaterialSettings.values()) {
            var material = settings.getMaterial();
            ModStats.registerMaterialOpen(MOD_ID, material);
            ReinforcedStorageMenuTypes.registerSingle(material);
            ModBlocks.registerMaterial(material);
            ModBlockEntityTypes.registerMaterial(material);
        }

        LOGGER.info("Registered {} reinforced barrel tiers for Minecraft 26.2 compatibility", ReinforcingMaterialSettings.values().length);
    }
}
