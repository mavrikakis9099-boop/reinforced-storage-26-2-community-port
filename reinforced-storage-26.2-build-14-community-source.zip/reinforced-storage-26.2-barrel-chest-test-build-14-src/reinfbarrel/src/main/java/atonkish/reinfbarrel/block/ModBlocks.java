package atonkish.reinfbarrel.block;

import java.util.LinkedHashMap;
import java.util.Map;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfcore.item.ModCreativeModeTabs;
import atonkish.reinfcore.util.ReinforcingMaterial;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Exact legacy block/item identifiers for the 26.2 compatibility port. */
public final class ModBlocks {
    public static final Map<ReinforcingMaterial, ReinforcedBarrelBlock> REINFORCED_BARREL_MAP = new LinkedHashMap<>();

    private ModBlocks() {
    }

    public static ReinforcedBarrelBlock registerMaterial(ReinforcingMaterial material) {
        return REINFORCED_BARREL_MAP.computeIfAbsent(material, key -> {
            String path = key.getName() + "_barrel";
            Identifier id = Identifier.fromNamespaceAndPath(ReinforcedBarrelsMod.MOD_ID, path);
            ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
            ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);

            // Preserve vanilla barrel mechanics. Tier-specific hardness/sound polish can be restored
            // after the migration contract has passed; these properties are not serialized world data.
            BlockBehaviour.Properties properties = BlockBehaviour.Properties.ofFullCopy(Blocks.BARREL).setId(blockKey);
            ReinforcedBarrelBlock block = new ReinforcedBarrelBlock(key, properties);
            Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

            Item.Properties itemProperties = new Item.Properties().useBlockDescriptionPrefix().setId(itemKey);
            if ("netherite".equals(key.getName())) {
                itemProperties = itemProperties.fireResistant();
            }
            BlockItem blockItem = new BlockItem(block, itemProperties);
            Registry.register(BuiltInRegistries.ITEM, itemKey, blockItem);
            ModCreativeModeTabs.addStorageItem(blockItem);
            return block;
        });
    }
}
