#!/usr/bin/env python3
"""Static contract preflight, not a substitute for Java compilation or runtime tests."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = json.loads((ROOT / "docs/compatibility_contract.json").read_text())
LEGACY = ROOT / "legacy_reference"
TEXTURE_COMPAT_PACK = ROOT / "compat_resource_pack"

JAR_FOR_MOD = {
    "reinfbarrel": "reinforced-barrels-2.7.5+1.21.11.jar",
    "reinfchest": "reinforced-chests-4.0.0-beta+1.21.11.jar",
    "reinfshulker": "reinforced-shulker-boxes-3.5.0-beta+1.21.11.jar",
}

TIERS = {
    "copper": 45,
    "iron": 54,
    "gold": 81,
    "diamond": 108,
    "netherite": 108,
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    raise SystemExit(1)


# Migration-sensitive runtime behavior recovered from the exact 1.21.11 jars.
def require_text(path: Path, needles: list[str], label: str) -> None:
    text = path.read_text()
    missing = [needle for needle in needles if needle not in text]
    if missing:
        fail(f"{label} missing required migration behavior: {missing}")


def matches_frozen_or_scoped_compatibility_hash(
    relative_path: str, path: Path, expected_hash: str
) -> bool:
    """Accept Build 6 byte identity or the one explicitly-scoped client marker edit.

    Nemo's Inventory Sorting identifies the legacy storage menu by its historical binary name.
    Build 9 keeps that name as a marker interface on the unchanged menu implementation.  The
    normalization below makes the exception narrow: any other edit to the migration-proven menu
    still fails the frozen-file check.
    """
    if path.is_file() and sha256(path) == expected_hash:
        return True
    if relative_path != "reinfcore/src/main/java/atonkish/reinfcore/screen/ReinforcedStorageMenu.java":
        return False
    if not path.is_file():
        return False
    source = path.read_text()
    marker = (
        "public final class ReinforcedStorageMenu extends AbstractContainerMenu "
        "implements ReinforcedStorageScreenHandler"
    )
    if source.count(marker) != 1:
        return False
    normalized = source.replace(
        marker,
        "public final class ReinforcedStorageMenu extends AbstractContainerMenu",
        1,
    )
    return hashlib.sha256(normalized.encode()).hexdigest() == expected_hash

def main() -> int:
    print("Static preflight only: Java API compatibility still requires compilation.")
    # Exact binary provenance.
    for filename, expected in CONTRACT["sha256"].items():
        path = LEGACY / filename
        if not path.is_file():
            fail(f"missing legacy reference {filename}")
        actual = sha256(path)
        if actual != expected:
            fail(f"SHA-256 mismatch for {filename}: {actual} != {expected}")

    # Resource parity: every legacy asset/data path recorded in the contract must exist both in
    # the old jar and in the corresponding 26.2 source module.
    for mod_id, spec in CONTRACT["mods"].items():
        jar_path = LEGACY / JAR_FOR_MOD[mod_id]
        with zipfile.ZipFile(jar_path) as jar:
            legacy_names = set(jar.namelist())
        source_root = ROOT / mod_id / "src/main/resources"
        for resource in spec["resource_paths"]:
            if resource not in legacy_names:
                fail(f"contract drift: {resource} is not in {jar_path.name}")
            if not (source_root / resource).is_file():
                fail(f"26.2 source is missing legacy resource {mod_id}:{resource}")

    # Barrel registry IDs and capacities must be visible in source before we risk opening a world.
    barrel_sources = "\n".join(
        p.read_text(errors="replace")
        for p in (ROOT / "reinfbarrel/src/main/java").rglob("*.java")
    )
    for tier, size in TIERS.items():
        if f'"{tier}", {size}' not in barrel_sources:
            fail(f"barrel tier contract missing from source: {tier}={size}")
        legacy_id = f"{tier}_barrel"
        # Dynamic ID construction is acceptable if the suffix is fixed and the tier is defined.
        if '"_barrel"' not in barrel_sources or f'"{tier}"' not in barrel_sources:
            fail(f"barrel registry construction does not visibly preserve {legacy_id}")

    # Chest contract: same tiers/capacities and both exact single/double core menu namespaces.
    chest_sources = "\n".join(
        p.read_text(errors="replace")
        for p in (ROOT / "reinfchest/src/main/java").rglob("*.java")
    )
    for tier, size in TIERS.items():
        if f'"{tier}", {size}' not in chest_sources:
            fail(f"chest tier contract missing from source: {tier}={size}")
    if '"_chest"' not in chest_sources:
        fail("chest registry construction does not preserve *_chest IDs")

    core_sources = "\n".join(
        p.read_text(errors="replace")
        for p in (ROOT / "reinfcore/src/main/java").rglob("*.java")
    )
    for prefix in ('"single_"', '"double_"'):
        if prefix not in core_sources or '"_block"' not in core_sources:
            fail(f"core menu ID construction missing {prefix}* + _block")

    # Old datafixer mixins are intentionally not allowed back into the first migration build.
    forbidden = ("ItemStackComponentizationFixMixin", "Schema1460Mixin")
    port_sources = "\n".join(
        p.read_text(errors="replace")
        for module in ("reinfbarrel", "reinfchest", "reinfshulker")
        for p in (ROOT / module).rglob("*.java")
    )
    for name in forbidden:
        if name in port_sources:
            fail(f"legacy datafixer mixin was reintroduced: {name}")

    print("PASS: exact legacy jar hashes")
    print("PASS: recorded legacy asset/data paths copied into 26.2 modules")
    print("PASS: reinforced barrel tier sizes and ID construction")
    print("PASS: reinforced chest tier sizes and single/double menu ID construction")
    print("PASS: obsolete 1.21 datafixer mixins remain excluded")

    require_text(
        ROOT / "reinfbarrel/src/main/java/atonkish/reinfbarrel/block/entity/ReinforcedBarrelBlockEntity.java",
        ["ContainerOpenersCounter", "ReinforcedStorageMenu", "incrementOpeners", "decrementOpeners", "BarrelBlock.OPEN"],
        "reinforced barrel opener counter",
    )
    require_text(
        ROOT / "reinfbarrel/src/main/java/atonkish/reinfbarrel/block/entity/ModBlockEntityTypes.java",
        ["BlockEntityTypes.BARREL", "reinfbarrel$setValidBlocks"],
        "vanilla BARREL valid-block bridge",
    )
    barrel_type_source = (
        ROOT / "reinfbarrel/src/main/java/atonkish/reinfbarrel/block/entity/ModBlockEntityTypes.java"
    ).read_text()
    if "BlockEntityType.BARREL" in barrel_type_source:
        fail("removed 26.2 symbol BlockEntityType.BARREL was reintroduced")
    require_text(
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/block/entity/ReinforcedChestBlockEntity.java",
        ["ContainerOpenersCounter", "CompoundContainer", "compound.contains", "signalOpenCount"],
        "reinforced chest opener counter",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/screen/ReinforcedStorageMenu.java",
        ["public Container getContainer()"],
        "menu backing-container identity",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/screen/ReinforcedStorageScreenHandler.java",
        ["public interface ReinforcedStorageScreenHandler"],
        "Nemo legacy storage-menu marker",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/screen/ReinforcedStorageMenu.java",
        ["implements ReinforcedStorageScreenHandler"],
        "Nemo legacy storage-menu marker",
    )
    screen_path = ROOT / "reinfcore/src/main/java/atonkish/reinfcore/client/gui/screen/ReinforcedStorageScreen.java"
    screen_source = screen_path.read_text()
    if "super(menu, inventory, title, getImageWidth(menu), getImageHeight(menu));" not in screen_source:
        fail("26.2 screen dimensions are not supplied through the immutable superclass constructor")
    if re.search(r"this\.image(?:Width|Height)\s*=", screen_source):
        fail("26.2 final screen dimensions are assigned after superclass construction")
    require_text(
        screen_path,
        [
            "VANILLA_CHEST_TEXTURE",
            "textures/gui/container/generic_54.png",
            "VANILLA_GRID_WIDTH",
            "VANILLA_GRID_HEIGHT",
            "VANILLA_PLAYER_SECTION_TEXTURE_Y",
            "drawVanillaCompatibleBackground",
            "blitTiled",
            "graphics.blit(",
            "playerPanelX",
            "alignNemoPlayerButtons",
            "isNemoDefaultInventoryButton",
            "playerButtonShift",
            "widget.setX",
        ],
        "pack-overridable reinforced storage inventory screen and Nemo alignment",
    )
    if "graphics.fill(" in screen_source:
        fail("storage inventory screen still hard-codes a non-pack-overridable fill panel")
    if screen_source.count("graphics.blitSprite(") != 1 or "SCROLLER_TEXTURE" not in screen_source:
        fail("storage inventory screen overlays separate slot sprites on generic_54 cell artwork")
    if "blitTextureSample" in screen_source:
        fail("storage inventory screen reintroduced single-pixel panel expansion")

    chest_manifest_path = ROOT / "reinfchest/src/main/resources/fabric.mod.json"
    chest_manifest = json.loads(chest_manifest_path.read_text())
    chest_client_entrypoints = chest_manifest.get("entrypoints", {}).get("client", [])
    if "atonkish.reinfchest.ReinforcedChestsClientMod" not in chest_client_entrypoints:
        fail("reinforced chest client initializer is not registered in fabric.mod.json")
    require_text(
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/ReinforcedChestsClientMod.java",
        [
            "ClientModInitializer",
            "BlockEntityRenderers.register",
            "new ReinforcedChestRenderer(context, material)",
            "ModBlockEntityTypes.REINFORCED_CHEST_MAP.forEach((material, type)",
        ],
        "reinforced chest tier-aware renderer registration",
    )
    require_text(
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/client/render/blockentity/ReinforcedChestRenderer.java",
        [
            "extends ChestRenderer<ReinforcedChestBlockEntity>",
            "public void submit(",
            "ChestRenderer.LAYERS.map",
            "ChestRenderer.modelTransformation(state.facing)",
            "ChestRenderState.ChestMaterialType.CHRISTMAS",
            "super.submit(state, poseStack, submitNodeCollector, camera)",
            "tierSprites.select(state.type), tierSpriteGetter, 0, state.breakProgress",
            "state.lightCoords, OverlayTexture.NO_OVERLAY, -1",
            "open = 1.0F - open * open * open",
            "poseStack.popPose()",
        ],
        "vanilla-compatible tier-aware chest submission",
    )
    renderer_source = (
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/client/render/blockentity/ReinforcedChestRenderer.java"
    ).read_text()
    if "customSprite" in renderer_source or "getCustomSprite" in renderer_source:
        fail("NeoForge-only custom-sprite hook reintroduced into the Fabric renderer")
    if "extractRenderState(" in renderer_source or "createRenderState(" in renderer_source:
        fail("Build 8 must inherit vanilla chest state extraction/creation unchanged")
    if "net.neoforged" in port_sources or "net.minecraftforge" in port_sources:
        fail("Forge/NeoForge API introduced into the Fabric sources")
    require_text(
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/client/render/ModChestSprites.java",
        [
            "Sheets.CHEST_SHEET",
            '"entity/chest/" + material.getName() + "/" + variant',
            'case LEFT -> "left"',
            'case RIGHT -> "right"',
            'case SINGLE -> "single"',
        ],
        "legacy reinforced chest single/left/right sprite mapping",
    )
    chest_atlas = json.loads(
        (ROOT / "reinfchest/src/main/resources/assets/minecraft/atlases/chests.json").read_text()
    )
    atlas_sources = {source.get("source") for source in chest_atlas.get("sources", [])}
    expected_atlas_sources = {
        f"entity/chest/{material}" for material in ("copper", "iron", "gold", "diamond", "netherite")
    }
    if atlas_sources != expected_atlas_sources:
        fail("chest atlas does not stitch all five legacy tier texture directories")
    for source in chest_atlas["sources"]:
        if source.get("type") not in ("directory", "minecraft:directory"):
            fail("unexpected chest atlas source type")
        if source.get("prefix") != source["source"] + "/":
            fail("chest atlas prefix would alter the legacy sprite identifiers")
    with zipfile.ZipFile(LEGACY / JAR_FOR_MOD["reinfchest"]) as jar:
        for tier in TIERS:
            for variant in ("single", "left", "right"):
                resource = f"assets/reinfchest/textures/entity/chest/{tier}/{variant}.png"
                if (ROOT / "reinfchest/src/main/resources" / resource).read_bytes() != jar.read(resource):
                    fail(f"legacy chest texture changed: {tier}/{variant}")

    config_path = ROOT / "reinfcore/src/main/java/atonkish/reinfcore/ReinforcedCoreConfig.java"
    require_text(
        config_path,
        [
            "@Config(name = ReinforcedCoreMod.MOD_ID)",
            "implements ConfigData",
            "EnumDisplayOption.BUTTON",
            "CollapsibleObject(startExpanded = true)",
            "BoundedDiscrete(min = 6, max = 9)",
        ],
        "Reinforced Core AutoConfig schema",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/ReinforcedCoreMod.java",
        ["AutoConfig.register", "GsonConfigSerializer::new", "getConfigHolder"],
        "Reinforced Core persistent AutoConfig registration",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/integration/modmenu/ModMenu.java",
        ["implements ModMenuApi", "AutoConfigClient.getConfigScreen"],
        "Reinforced Core Mod Menu integration",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/screen/ReinforcedStorageMenu.java",
        ["scrollItems", "shouldShowScrollbar", "SlotAccessor", "HIDDEN_SLOT_COORDINATE"],
        "Reinforced Core Scroll slot window",
    )
    core_manifest = json.loads((ROOT / "reinfcore/src/main/resources/fabric.mod.json").read_text())
    if core_manifest.get("entrypoints", {}).get("modmenu") != [
        "atonkish.reinfcore.integration.modmenu.ModMenu"
    ]:
        fail("Reinforced Core Mod Menu entrypoint is missing")
    if core_manifest.get("mixins") != ["reinfcore.mixins.json"]:
        fail("Reinforced Core slot accessor mixin is missing")

    # Freeze the migration-proven Build 6 runtime outside the explicitly scoped later changes.
    frozen = json.loads((ROOT / "docs/build6_runtime_sha256.json").read_text())
    for relative_path, expected_hash in frozen["protected_files"].items():
        path = ROOT / relative_path
        if not matches_frozen_or_scoped_compatibility_hash(relative_path, path, expected_hash):
            fail(f"Build 6 migration-proven file changed: {relative_path}")
    permitted = (
        set(frozen["protected_files"])
        | set(frozen["allowed_visual_files"])
        | set(frozen["allowed_build14_files"])
    )
    for module in ("reinfcore", "reinfbarrel", "reinfchest"):
        for path in (ROOT / module / "src/main").rglob("*"):
            if path.is_file() and path.relative_to(ROOT).as_posix() not in permitted:
                fail(f"unexpected file outside the scoped visual change: {path.relative_to(ROOT)}")
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/ReinforcedCoreMod.java",
        ["ModCreativeModeTabs.init();"],
        "reinforced storage creative-tab initialization",
    )
    require_text(
        ROOT / "reinfcore/src/main/java/atonkish/reinfcore/item/ModCreativeModeTabs.java",
        [
            'Identifier.fromNamespaceAndPath(ReinforcedCoreMod.MOD_ID, "reinforced_storage")',
            'Component.translatable("itemGroup.reinfcore.reinforced_storage")',
            "FabricCreativeModeTab.builder()",
            "CreativeModeTabs.FUNCTIONAL_BLOCKS",
            "CreativeModeTabs.REDSTONE_BLOCKS",
            "CreativeModeTabEvents.modifyOutputEvent(REINFORCED_STORAGE_KEY)",
        ],
        "legacy creative-tab membership",
    )
    for module in ("reinfbarrel", "reinfchest"):
        require_text(
            ROOT / f"{module}/src/main/java/atonkish/{module}/block/ModBlocks.java",
            ["ModCreativeModeTabs.addStorageItem(blockItem);"],
            f"{module} creative-tab registration",
        )
    require_text(
        ROOT / "reinfbarrel/src/main/java/atonkish/reinfbarrel/stat/ModStats.java",
        [
            "OPEN_REINFORCED_BARREL_MAP",
            '"open_" + key.getName() + "_barrel"',
            "Registry.register(BuiltInRegistries.CUSTOM_STAT, name, identifier)",
            "Stats.CUSTOM.get(identifier, formatter)",
        ],
        "legacy reinforced-barrel statistics",
    )
    require_text(
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/stat/ModStats.java",
        [
            "OPEN_REINFORCED_CHEST_MAP",
            '"open_" + key.getName() + "_chest"',
            "Registry.register(BuiltInRegistries.CUSTOM_STAT, name, identifier)",
            "Stats.CUSTOM.get(identifier, formatter)",
        ],
        "legacy reinforced-chest statistics",
    )
    require_text(
        ROOT / "reinfbarrel/src/main/java/atonkish/reinfbarrel/block/ReinforcedBarrelBlock.java",
        [
            "useWithoutItem",
            "player.awardStat(ModStats.OPEN_REINFORCED_BARREL_MAP.get(material))",
            "PiglinAi.angerNearbyPiglins",
        ],
        "legacy reinforced-barrel stat increment",
    )
    require_text(
        ROOT / "reinfchest/src/main/java/atonkish/reinfchest/block/ReinforcedChestBlock.java",
        [
            "getOpenChestStat",
            "Stats.CUSTOM.get(ModStats.OPEN_REINFORCED_CHEST_MAP.get(material))",
        ],
        "legacy reinforced-chest stat increment",
    )

    # Build 9 ships the resource-pack bridge separately from the jars. It deliberately maps only
    # visual resources to vanilla IDs: the active dark/global pack can then supply the textures,
    # while the normal tier-specific skins remain available when the bridge is disabled.
    pack_meta_path = TEXTURE_COMPAT_PACK / "pack.mcmeta"
    pack_meta = json.loads(pack_meta_path.read_text())
    if pack_meta.get("pack", {}).get("pack_format") != 88:
        fail("26.2 vanilla texture compatibility pack must use resource-pack format 88")
    atlas_path = TEXTURE_COMPAT_PACK / "assets/minecraft/atlases/chests.json"
    atlas = json.loads(atlas_path.read_text())
    sources = atlas.get("sources", [])
    directory_sources = [source for source in sources if source.get("type") == "minecraft:directory"]
    if directory_sources != [{
        "type": "minecraft:directory",
        "prefix": "entity/chest/",
        "source": "entity/chest",
    }]:
        fail("vanilla texture compatibility pack must retain the vanilla chest directory source")
    single_sources = [source for source in sources if source.get("type") == "minecraft:single"]
    expected_single_sources = []
    for material in TIERS:
        for variant, vanilla in (("single", "normal"), ("left", "normal_left"), ("right", "normal_right")):
            expected_single_sources.append({
                "type": "minecraft:single",
                "resource": f"minecraft:entity/chest/{vanilla}",
                "sprite": f"reinfchest:entity/chest/{material}/{variant}",
            })
    if single_sources != expected_single_sources:
        fail("vanilla texture compatibility pack chest aliases are incomplete or out of order")
    for material in TIERS:
        item_path = TEXTURE_COMPAT_PACK / f"assets/reinfchest/items/{material}_chest.json"
        item_model = json.loads(item_path.read_text())
        fallback = item_model.get("model", {}).get("fallback", {})
        chest_model = fallback.get("model", {})
        if chest_model.get("type") != "minecraft:chest" or chest_model.get("texture") != "minecraft:normal":
            fail(f"vanilla texture compatibility pack item alias is incomplete: {material}_chest")
        for suffix, top in (("", "minecraft:block/barrel_top"), ("_open", "minecraft:block/barrel_top_open")):
            model_path = TEXTURE_COMPAT_PACK / f"assets/reinfbarrel/models/block/{material}_barrel{suffix}.json"
            model = json.loads(model_path.read_text())
            textures = model.get("textures", {})
            if (
                textures.get("top") != top
                or textures.get("bottom") != "minecraft:block/barrel_bottom"
                or textures.get("side") != "minecraft:block/barrel_side"
            ):
                fail(f"vanilla texture compatibility pack barrel alias is incomplete: {material}{suffix}")
    if not (TEXTURE_COMPAT_PACK / "README.txt").is_file():
        fail("vanilla texture compatibility pack is missing its installation notes")
    en_us = json.loads((ROOT / "reinfcore/src/main/resources/assets/reinfcore/lang/en_us.json").read_text())
    if en_us.get("itemGroup.reinfcore.reinforced_storage") != "Reinforced Storage":
        fail("legacy Reinforced Storage creative-tab title is missing")
    print("PASS: legacy opener-counter and block-entity bridge behavior preserved")
    print("PASS: 26.2 immutable screen dimensions supplied at construction")
    print("PASS: storage inventory screen uses pack-overridable chest-sheet cells; composition has a separate executable test")
    print("PASS: 26.2 vanilla barrel type resolved through BlockEntityTypes")
    print("PASS: client-only renderer registered for all reinforced chest block-entity types")
    print("PASS: no NeoForge sprite hooks; vanilla chest extraction remains inherited")
    print("PASS: all 15 legacy chest PNGs unchanged and atlas paths resolve")
    print(f"PASS: {len(frozen['protected_files'])} migration-proven Build 6 runtime files unchanged")
    print("PASS: all storage items restored to Functional, Redstone, and Reinforced Storage creative tabs")
    print("PASS: all ten legacy custom statistics and per-tier increments restored")
    print("PASS: optional vanilla texture compatibility pack maps chest/barrel visuals to pack-overridable IDs")
    return 0


if __name__ == "__main__":
    sys.exit(main())
