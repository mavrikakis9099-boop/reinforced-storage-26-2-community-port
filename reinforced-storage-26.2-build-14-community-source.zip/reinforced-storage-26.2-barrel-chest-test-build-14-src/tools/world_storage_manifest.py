#!/usr/bin/env python3
"""Create and compare offline manifests of Reinforced Storage world data.

The tool intentionally has no third-party dependencies.  It reads Minecraft's
NBT and Anvil region formats directly so the exact pre-migration and
post-migration saves can be compared without loading either world again.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import re
import struct
import sys
import zlib
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


REINFORCED_NAMESPACES = ("reinfbarrel:", "reinfchest:")
REGION_RE = re.compile(r"^r\.(-?\d+)\.(-?\d+)\.mca$")
EXPECTED_CAPACITIES = {
    "reinfbarrel:copper_barrel": 45,
    "reinfbarrel:iron_barrel": 54,
    "reinfbarrel:gold_barrel": 81,
    "reinfbarrel:diamond_barrel": 108,
    "reinfbarrel:netherite_barrel": 108,
    "reinfchest:copper_chest": 45,
    "reinfchest:iron_chest": 54,
    "reinfchest:gold_chest": 81,
    "reinfchest:diamond_chest": 108,
    "reinfchest:netherite_chest": 108,
}


class NBTError(RuntimeError):
    pass


@dataclass
class NBTReader:
    data: bytes
    offset: int = 0

    def take(self, count: int) -> bytes:
        end = self.offset + count
        if end > len(self.data):
            raise NBTError(
                f"NBT ended at byte {len(self.data)} while reading {count} bytes "
                f"from offset {self.offset}"
            )
        result = self.data[self.offset:end]
        self.offset = end
        return result

    def unpack(self, fmt: str) -> Any:
        size = struct.calcsize(fmt)
        return struct.unpack(fmt, self.take(size))[0]

    def string(self) -> str:
        length = self.unpack(">H")
        return self.take(length).decode("utf-8", errors="strict")

    def payload(self, tag_type: int) -> Any:
        if tag_type == 0:
            return None
        if tag_type == 1:
            return self.unpack(">b")
        if tag_type == 2:
            return self.unpack(">h")
        if tag_type == 3:
            return self.unpack(">i")
        if tag_type == 4:
            return self.unpack(">q")
        if tag_type == 5:
            value = self.unpack(">f")
            return value if math.isfinite(value) else str(value)
        if tag_type == 6:
            value = self.unpack(">d")
            return value if math.isfinite(value) else str(value)
        if tag_type == 7:
            length = self.unpack(">i")
            if length < 0:
                raise NBTError(f"Negative byte-array length: {length}")
            return {"__nbt_byte_array__": self.take(length).hex()}
        if tag_type == 8:
            return self.string()
        if tag_type == 9:
            child_type = self.unpack(">B")
            length = self.unpack(">i")
            if length < 0:
                raise NBTError(f"Negative list length: {length}")
            return [self.payload(child_type) for _ in range(length)]
        if tag_type == 10:
            result: dict[str, Any] = {}
            while True:
                child_type = self.unpack(">B")
                if child_type == 0:
                    return result
                name = self.string()
                result[name] = self.payload(child_type)
        if tag_type == 11:
            length = self.unpack(">i")
            if length < 0:
                raise NBTError(f"Negative int-array length: {length}")
            return {
                "__nbt_int_array__": [self.unpack(">i") for _ in range(length)]
            }
        if tag_type == 12:
            length = self.unpack(">i")
            if length < 0:
                raise NBTError(f"Negative long-array length: {length}")
            return {
                "__nbt_long_array__": [self.unpack(">q") for _ in range(length)]
            }
        raise NBTError(f"Unknown NBT tag type {tag_type} at offset {self.offset}")

    def root(self) -> tuple[str, Any]:
        tag_type = self.unpack(">B")
        if tag_type == 0:
            return "", None
        name = self.string()
        value = self.payload(tag_type)
        return name, value


def parse_nbt(data: bytes) -> Any:
    reader = NBTReader(data)
    _name, value = reader.root()
    return value


def load_nbt_file(path: Path) -> Any:
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    return parse_nbt(raw)


def decompress_chunk(compression: int, payload: bytes, external_path: Path) -> bytes:
    external = bool(compression & 0x80)
    compression &= 0x7F
    if external:
        if not external_path.exists():
            raise NBTError(f"Missing external chunk payload {external_path}")
        payload = external_path.read_bytes()
    if compression == 1:
        return gzip.decompress(payload)
    if compression == 2:
        return zlib.decompress(payload)
    if compression == 3:
        return payload
    if compression == 4:
        raise NBTError(
            "LZ4-compressed region chunk encountered; this dependency-free "
            "auditor currently supports the normal GZip, zlib, and raw formats"
        )
    raise NBTError(f"Unknown region compression type {compression}")


def region_chunks(path: Path) -> Iterable[tuple[int, int, Any]]:
    match = REGION_RE.match(path.name)
    if not match:
        return
    region_x, region_z = (int(value) for value in match.groups())
    with path.open("rb") as handle:
        header = handle.read(8192)
        if len(header) < 8192:
            if not header:
                return
            raise NBTError(f"Truncated region header: {path}")
        for index in range(1024):
            entry = header[index * 4 : index * 4 + 4]
            sector_offset = int.from_bytes(entry[:3], "big")
            sector_count = entry[3]
            if sector_offset == 0 or sector_count == 0:
                continue
            local_x = index & 31
            local_z = index >> 5
            chunk_x = region_x * 32 + local_x
            chunk_z = region_z * 32 + local_z
            handle.seek(sector_offset * 4096)
            length_raw = handle.read(4)
            if len(length_raw) != 4:
                raise NBTError(f"Missing chunk length in {path} at index {index}")
            length = int.from_bytes(length_raw, "big")
            if length < 1 or length > sector_count * 4096:
                raise NBTError(
                    f"Invalid chunk length {length} in {path} at index {index}"
                )
            compression_raw = handle.read(1)
            if not compression_raw:
                raise NBTError(f"Missing compression byte in {path} at index {index}")
            compressed = handle.read(length - 1)
            external = path.with_name(f"c.{chunk_x}.{chunk_z}.mcc")
            raw = decompress_chunk(compression_raw[0], compressed, external)
            yield chunk_x, chunk_z, parse_nbt(raw)


def dimension_for_region(world: Path, region: Path) -> str:
    relative = region.parent.parent.relative_to(world)
    parts = relative.parts
    if not parts:
        return "minecraft:overworld"
    if parts == ("DIM-1",):
        return "minecraft:the_nether"
    if parts == ("DIM1",):
        return "minecraft:the_end"
    if len(parts) >= 3 and parts[0] == "dimensions":
        return f"{parts[1]}:{'/'.join(parts[2:])}"
    return relative.as_posix()


def walk_compounds(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk_compounds(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_compounds(child)


def first_key(compound: dict[str, Any], *names: str, default: Any = None) -> Any:
    for name in names:
        if name in compound:
            return compound[name]
    return default


def is_stack(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    item_id = first_key(value, "id", "Id")
    return isinstance(item_id, str) and (
        "count" in value or "Count" in value or "Slot" in value or "slot" in value
    )


def normalize_stack(stack: dict[str, Any]) -> dict[str, Any]:
    item_id = first_key(stack, "id", "Id", default="")
    count = first_key(stack, "count", "Count", default=1)
    slot = first_key(stack, "Slot", "slot")
    result: dict[str, Any] = {"id": item_id, "count": int(count)}
    if slot is not None:
        # NBT byte slots above 127 are represented as signed values.
        slot_value = int(slot)
        if slot_value < 0:
            slot_value += 256
        result["slot"] = slot_value
        result["slot_1_based"] = slot_value + 1
    extra = {
        key: value
        for key, value in stack.items()
        if key not in {"id", "Id", "count", "Count", "Slot", "slot"}
    }
    if extra:
        result["data"] = extra
    return result


def extract_stacks(value: Any) -> list[dict[str, Any]]:
    result = []
    if isinstance(value, list):
        for entry in value:
            if is_stack(entry):
                result.append(normalize_stack(entry))
    return sorted(result, key=lambda item: (item.get("slot", 10_000), item["id"]))


def reinforced_item_refs(value: Any, location: str) -> list[dict[str, Any]]:
    refs = []
    for compound in walk_compounds(value):
        if not is_stack(compound):
            continue
        stack = normalize_stack(compound)
        if str(stack["id"]).startswith(REINFORCED_NAMESPACES):
            refs.append({"location": location, **stack})
    return refs


def likely_block_entities(chunk: Any) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    seen: set[int] = set()
    for compound in walk_compounds(chunk):
        object_id = id(compound)
        if object_id in seen:
            continue
        block_id = compound.get("id")
        if (
            isinstance(block_id, str)
            and isinstance(compound.get("x"), int)
            and isinstance(compound.get("y"), int)
            and isinstance(compound.get("z"), int)
        ):
            seen.add(object_id)
            candidates.append(compound)
    return candidates


def container_record(
    dimension: str, chunk_x: int, chunk_z: int, block_entity: dict[str, Any]
) -> dict[str, Any]:
    items_value = first_key(block_entity, "Items", "items", default=[])
    items = extract_stacks(items_value)
    ignored = {
        "id",
        "x",
        "y",
        "z",
        "Items",
        "items",
        "keepPacked",
        "LastUpdate",
    }
    metadata = {
        key: value for key, value in block_entity.items() if key not in ignored
    }
    block_entity_id = block_entity["id"]
    expected_capacity = EXPECTED_CAPACITIES.get(block_entity_id)
    populated_slot_numbers = {item.get("slot_1_based") for item in items}
    result = {
        "dimension": dimension,
        "chunk": [chunk_x, chunk_z],
        "position": [
            int(block_entity["x"]),
            int(block_entity["y"]),
            int(block_entity["z"]),
        ],
        "block_entity_id": block_entity_id,
        "expected_capacity": expected_capacity,
        "populated_slots": len(items),
        "max_populated_slot_1_based": max(
            (item.get("slot_1_based", 0) for item in items), default=0
        ),
        "items": items,
    }
    if expected_capacity is not None:
        result["final_slot_populated"] = expected_capacity in populated_slot_numbers
    if metadata:
        result["metadata"] = metadata
    return result


def canonical_hash(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def snapshot_world(world: Path) -> dict[str, Any]:
    world = world.resolve()
    if not (world / "level.dat").is_file():
        raise SystemExit(f"Not a Minecraft world directory (level.dat missing): {world}")

    level = load_nbt_file(world / "level.dat")
    level_data = level.get("Data", level) if isinstance(level, dict) else {}
    containers: list[dict[str, Any]] = []
    item_refs: list[dict[str, Any]] = []
    region_errors: list[dict[str, str]] = []
    chunks_scanned = 0
    block_entities_scanned = 0

    region_paths = sorted(world.glob("region/*.mca"))
    region_paths += sorted(world.glob("DIM-1/region/*.mca"))
    region_paths += sorted(world.glob("DIM1/region/*.mca"))
    region_paths += sorted(world.glob("dimensions/**/region/*.mca"))
    region_paths = list(dict.fromkeys(region_paths))

    for region_path in region_paths:
        dimension = dimension_for_region(world, region_path)
        try:
            for chunk_x, chunk_z, chunk in region_chunks(region_path):
                chunks_scanned += 1
                for block_entity in likely_block_entities(chunk):
                    block_entities_scanned += 1
                    location = (
                        f"block_entity:{dimension}:"
                        f"{block_entity['x']},{block_entity['y']},{block_entity['z']}:"
                        f"{block_entity['id']}"
                    )
                    item_refs.extend(reinforced_item_refs(block_entity, location))
                    if str(block_entity["id"]).startswith(REINFORCED_NAMESPACES):
                        containers.append(
                            container_record(
                                dimension, chunk_x, chunk_z, block_entity
                            )
                        )
        except Exception as exc:  # Report all unreadable regions in the manifest.
            region_errors.append({"region": str(region_path), "error": str(exc)})

    players: list[dict[str, Any]] = []
    # 1.21.x stores player NBT in playerdata/. 26.2's file-layout migration
    # moves it to players/data/. Support both so a moved file is not reported
    # as a lost inventory.
    player_paths = sorted((world / "playerdata").glob("*.dat"))
    player_paths += sorted((world / "players" / "data").glob("*.dat"))
    player_paths = list(dict.fromkeys(player_paths))
    for player_path in player_paths:
        if player_path.name.endswith(".dat_old"):
            continue
        player = load_nbt_file(player_path)
        inventories: dict[str, list[dict[str, Any]]] = {}
        for key in ("Inventory", "inventory", "EnderItems", "ender_items"):
            if isinstance(player, dict) and key in player:
                stacks = extract_stacks(player[key])
                inventories[key] = stacks
                item_refs.extend(
                    reinforced_item_refs(
                        player[key], f"player:{player_path.stem}:{key}"
                    )
                )
        players.append({"uuid": player_path.stem, "inventories": inventories})

    containers.sort(
        key=lambda item: (
            item["dimension"],
            item["position"][0],
            item["position"][1],
            item["position"][2],
            item["block_entity_id"],
        )
    )
    item_refs.sort(
        key=lambda item: (
            item["location"], item.get("slot", 10_000), item["id"]
        )
    )
    counts = Counter(item["block_entity_id"] for item in containers)
    all_container_stacks = [
        stack for container in containers for stack in container["items"]
    ]
    stack_counts = Counter(stack["count"] for stack in all_container_stacks)
    barrel_nonunit = sum(
        stack["count"] != 1
        for container in containers
        if str(container["block_entity_id"]).startswith("reinfbarrel:")
        for stack in container["items"]
    )
    chest_nonunit = sum(
        stack["count"] != 1
        for container in containers
        if str(container["block_entity_id"]).startswith("reinfchest:")
        for stack in container["items"]
    )
    component_bearing = sum("data" in stack for stack in all_container_stacks)
    manifest: dict[str, Any] = {
        "format": "reinforced-storage-world-manifest-v1",
        "world": {
            "directory_name": world.name,
            "level_name": first_key(level_data, "LevelName", "level_name"),
            "data_version": first_key(level_data, "DataVersion", "data_version"),
        },
        "scan": {
            "region_files": len(region_paths),
            "chunks": chunks_scanned,
            "block_entities": block_entities_scanned,
            "errors": region_errors,
        },
        "summary": {
            "reinforced_container_block_entities": len(containers),
            "by_block_entity_id": dict(sorted(counts.items())),
            "populated_inventory_slots": sum(
                item["populated_slots"] for item in containers
            ),
            "stack_count_distribution": {
                str(count): occurrences
                for count, occurrences in sorted(stack_counts.items())
            },
            "stacks_with_count_greater_than_one": sum(
                count != 1 and occurrences or 0
                for count, occurrences in stack_counts.items()
            ),
            "barrel_stacks_with_count_greater_than_one": barrel_nonunit,
            "chest_stacks_with_count_greater_than_one": chest_nonunit,
            "component_bearing_container_stacks": component_bearing,
            "containers_with_expected_final_slot_populated": sum(
                bool(item.get("final_slot_populated")) for item in containers
            ),
            "ready_for_stack_count_regression_test": bool(
                barrel_nonunit and chest_nonunit
            ),
            "reinforced_item_references_outside_or_inside_containers": len(item_refs),
        },
        "containers": containers,
        "reinforced_item_references": item_refs,
        "players": players,
    }
    manifest["fingerprints"] = {
        "containers_full": canonical_hash(containers),
        "container_slots_identity_count": canonical_hash(
            [
                {
                    "dimension": container["dimension"],
                    "position": container["position"],
                    "block_entity_id": container["block_entity_id"],
                    "items": [
                        {
                            "slot": item.get("slot"),
                            "id": item["id"],
                            "count": item["count"],
                        }
                        for item in container["items"]
                    ],
                }
                for container in containers
            ]
        ),
        "reinforced_item_references": canonical_hash(item_refs),
    }
    return manifest


def compare_manifests(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    def keyed(manifest: dict[str, Any]) -> dict[tuple[Any, ...], dict[str, Any]]:
        return {
            (
                item["dimension"],
                *item["position"],
                item["block_entity_id"],
            ): item
            for item in manifest["containers"]
        }

    old = keyed(before)
    new = keyed(after)
    missing_keys = sorted(set(old) - set(new))
    added_keys = sorted(set(new) - set(old))
    changed = []
    for key in sorted(set(old) & set(new)):
        old_items = old[key]["items"]
        new_items = new[key]["items"]
        if old_items != new_items or old[key].get("metadata") != new[key].get("metadata"):
            old_basic = [
                (item.get("slot"), item["id"], item["count"]) for item in old_items
            ]
            new_basic = [
                (item.get("slot"), item["id"], item["count"]) for item in new_items
            ]
            changed.append(
                {
                    "key": list(key),
                    "identity_or_count_changed": old_basic != new_basic,
                    "before": old[key],
                    "after": new[key],
                }
            )

    identity_changes = [item for item in changed if item["identity_or_count_changed"]]
    before_refs = before.get("reinforced_item_references", [])
    after_refs = after.get("reinforced_item_references", [])

    def basic_refs(refs: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            {
                "location": ref.get("location"),
                "slot": ref.get("slot"),
                "id": ref.get("id"),
                "count": ref.get("count"),
            }
            for ref in refs
        ]

    ref_identity_changed = basic_refs(before_refs) != basic_refs(after_refs)
    ref_exact_changed = before_refs != after_refs
    exact_container_changes = bool(changed)
    core_pass = (
        not missing_keys
        and not added_keys
        and not identity_changes
        and not ref_identity_changed
    )
    result = {
        "format": "reinforced-storage-world-comparison-v1",
        "pass": core_pass and not exact_container_changes and not ref_exact_changed,
        "core_identity_slot_count_pass": core_pass,
        "exact_components_and_metadata_pass": (
            not exact_container_changes and not ref_exact_changed
        ),
        "before_world": before.get("world"),
        "after_world": after.get("world"),
        "summary": {
            "before_containers": len(old),
            "after_containers": len(new),
            "missing_containers": len(missing_keys),
            "added_containers": len(added_keys),
            "containers_with_identity_slot_or_count_changes": len(identity_changes),
            "containers_with_only_metadata_or_component_changes": len(changed)
            - len(identity_changes),
            "reinforced_item_reference_identity_or_count_changed": ref_identity_changed,
            "reinforced_item_reference_components_changed": ref_exact_changed,
        },
        "missing": [list(key) for key in missing_keys],
        "added": [list(key) for key in added_keys],
        "changed": changed,
        "reinforced_item_references": {
            "before": before_refs,
            "after": after_refs,
        }
        if ref_exact_changed
        else {"changed": False},
    }
    return result


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(value: Any, output: Path | None) -> None:
    encoded = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(encoded)
    else:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(encoded, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    snapshot = subparsers.add_parser("snapshot", help="Snapshot an offline world")
    snapshot.add_argument("world", type=Path)
    snapshot.add_argument("--output", "-o", type=Path)

    compare = subparsers.add_parser("compare", help="Compare two manifest JSON files")
    compare.add_argument("before", type=Path)
    compare.add_argument("after", type=Path)
    compare.add_argument("--output", "-o", type=Path)

    args = parser.parse_args()
    if args.command == "snapshot":
        result = snapshot_world(args.world)
    else:
        result = compare_manifests(read_json(args.before), read_json(args.after))
    write_json(result, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
