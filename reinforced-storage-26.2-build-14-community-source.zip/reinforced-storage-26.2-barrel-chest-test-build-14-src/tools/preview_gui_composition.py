#!/usr/bin/env python3
"""Render recorded production-screen draws with synthetic fixtures or a supplied GUI PNG.

Optional QA tool requiring Pillow; never invoked by the normal build. This is a
CPU composition preview, not a Minecraft screenshot and not an image of Better-GUI.
"""
import argparse
from pathlib import Path
import sys
import tempfile

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from test_gui_composition import compile_probe, fixture_pixel, run_probe


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--texture", type=Path, help="Optional actual generic_54-layout PNG; not modified")
    args = parser.parse_args()
    cases = [("Gold barrel / 81 slots", 81, False, "light"),
             ("Diamond barrel / 108 slots", 108, False, "dark"),
             ("Double copper chest / 90 slots", 45, True, "patterned"),
             ("Double gold chest / 162 slots", 81, True, "dark"),
             ("Double netherite chest / 216 slots", 108, True, "dark"),
             ("Double netherite / alpha fixture", 108, True, "translucent")]
    cell_width, cell_height = 480, 342
    sheet = Image.new("RGB", (cell_width * 2, cell_height * 3 + 45), (23, 28, 35))
    text = ImageDraw.Draw(sheet)
    text.text((14, 12), "BUILD 13 - RECORDED JAVA DRAW OPERATIONS - CPU PREVIEW, NOT IN-GAME", fill="white")
    supplied = Image.open(args.texture).convert("RGBA") if args.texture else None
    if supplied is not None and (supplied.width != supplied.height or supplied.width % 256):
        raise ValueError("Expected a square 256-unit atlas, e.g. 256x256, 512x512 or 1024x1024")
    with tempfile.TemporaryDirectory(prefix="reinforced-preview-") as compiled:
        java = compile_probe(compiled)
        for index, (title, size, double, style) in enumerate(cases):
            probe = run_probe(java, compiled, size, double)
            texture = supplied or Image.new("RGBA", (256, 256))
            if supplied is None:
                texture.putdata([fixture_pixel(x, y, style) for y in range(256) for x in range(256)])
                # Distinct header tone exercises chrome vs cell-area composition.
                painter = ImageDraw.Draw(texture)
                painter.rectangle((0, 0, 175, 16), fill=(112, 78, 40, 144 if style == "translucent" else 255))
                for inset, color in ((0, (30, 30, 30)), (1, (175, 150, 95)), (2, (94, 70, 40))):
                    painter.line((inset, inset, 175-inset, inset), fill=(*color, 255))
            canvas = Image.new("RGBA", (cell_width, cell_height), (0, 0, 0, 0))
            checker = ImageDraw.Draw(canvas)
            for cy in range(0, cell_height, 12):
                for cx in range(0, cell_width, 12):
                    tone = (40, 46, 54) if (cy // 12 + cx // 12) % 2 else (47, 54, 63)
                    checker.rectangle((cx, cy, cx+11, cy+11), fill=(*tone, 255))
            scale = texture.width // 256
            for x, y, u, v, width, height, rw, rh, _, _ in probe["BLIT"]:
                region = texture.crop((u*scale, v*scale, (u+rw)*scale, (v+rh)*scale))
                if scale != 1:
                    region = region.resize((width, height), Image.Resampling.NEAREST)
                canvas.alpha_composite(region, (x, y))
            labels = ImageDraw.Draw(canvas)
            labels.text((20, 7), title + (" | supplied PNG" if supplied else " | " + style), fill="white")
            for label_index, (x, y, _) in enumerate(probe["TEXT"]):
                labels.text((20+x, 30+y), "Storage" if label_index == 0 else "Inventory", fill="white")
            sheet.paste(canvas.convert("RGB"), ((index % 2) * cell_width, 45 + index // 2 * cell_height))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(args.output)
    print(args.output.resolve())


if __name__ == "__main__":
    main()
