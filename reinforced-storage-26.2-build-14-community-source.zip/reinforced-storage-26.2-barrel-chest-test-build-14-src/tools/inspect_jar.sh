#!/usr/bin/env bash
set -euo pipefail
jarfile="$1"
out="${2:-$(basename "$jarfile" .jar)-inspection}"
mkdir -p "$out"
unzip -l "$jarfile" > "$out/file-list.txt"
unzip -p "$jarfile" fabric.mod.json > "$out/fabric.mod.json" 2>/dev/null || true
# Preserve all resource metadata for registry/data-contract inspection.
rm -rf "$out/extracted"
mkdir -p "$out/extracted"
unzip -q "$jarfile" -d "$out/extracted"
find "$out/extracted" -type f | sort > "$out/extracted-files.txt"
